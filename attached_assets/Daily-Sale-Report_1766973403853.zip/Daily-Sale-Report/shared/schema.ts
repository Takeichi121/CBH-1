import { sql } from "drizzle-orm";
import { pgTable, text, varchar, decimal, integer, timestamp, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  name: text("name").notNull(),
  role: text("role").notNull().default('staff'),
});

export const dailySalesReports = pgTable("daily_sales_reports", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  reportDate: text("report_date").notNull(),
  reportBy: varchar("report_by").notNull().references(() => users.id),
  workShift: text("work_shift").notNull(),
  dailyTarget: decimal("daily_target", { precision: 10, scale: 2 }).notNull(),
  actualSales: decimal("actual_sales", { precision: 10, scale: 2 }).notNull(),
  transactionCount: integer("transaction_count").notNull(),
  dineIn: decimal("dine_in", { precision: 10, scale: 2 }).notNull().default('0'),
  takeAway: decimal("take_away", { precision: 10, scale: 2 }).notNull().default('0'),
  delivery: decimal("delivery", { precision: 10, scale: 2 }).notNull().default('0'),
  deliveryBreakdown: jsonb("delivery_breakdown").$type<{
    grabfood?: number;
    lineman?: number;
    shopee?: number;
    foodpanda?: number;
    gokoo?: number;
    bkapp?: number;
  }>().default({}),
  sos: integer("sos"), // Speed of Service in seconds
  mtdSos: integer("mtd_sos"), // MTD Speed of Service in seconds
  voidCount: integer("void_count").default(0),
  tcmh: decimal("tcmh", { precision: 5, scale: 2 }),
  colAc: integer("col_ac"), // COL AC hours
  gsi: decimal("gsi", { precision: 3, scale: 2 }),
  osat: decimal("osat", { precision: 3, scale: 2 }),
  googleReview: decimal("google_review", { precision: 3, scale: 2 }),
  deliveryRating: decimal("delivery_rating", { precision: 3, scale: 2 }),
  wasteDaily: decimal("waste_daily", { precision: 10, scale: 2 }).default('0'),
  mealDaily: decimal("meal_daily", { precision: 10, scale: 2 }).default('0'),
  addCheese: decimal("add_cheese", { precision: 10, scale: 2 }).default('0'),
  vMeal: decimal("v_meal", { precision: 10, scale: 2 }).default('0'),
  upSize: decimal("up_size", { precision: 10, scale: 2 }).default('0'),
  rosterStaff: jsonb("roster_staff").$type<{
    phongsathorn?: string;
    nuttarika?: string;
    chanon?: string;
    wachiraphat?: string;
  }>().default({}),
  createdAt: timestamp("created_at").default(sql`NOW()`),
  updatedAt: timestamp("updated_at").default(sql`NOW()`),
});

export const storeSettings = pgTable("store_settings", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  storeName: text("store_name").notNull(),
  storeCode: text("store_code").notNull().unique(),
  dailyTarget: decimal("daily_target", { precision: 10, scale: 2 }).notNull(),
  createdAt: timestamp("created_at").default(sql`NOW()`),
  updatedAt: timestamp("updated_at").default(sql`NOW()`),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
  name: true,
  role: true,
});

export const insertDailySalesSchema = createInsertSchema(dailySalesReports).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertStoreSettingsSchema = createInsertSchema(storeSettings).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
export type InsertDailySales = z.infer<typeof insertDailySalesSchema>;
export type DailySalesReport = typeof dailySalesReports.$inferSelect;
export type InsertStoreSettings = z.infer<typeof insertStoreSettingsSchema>;
export type StoreSettings = typeof storeSettings.$inferSelect;
