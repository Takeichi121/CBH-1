import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useQuery } from "@tanstack/react-query";
import { format } from "date-fns";
import { useLanguage } from "@/contexts/language-context";

export default function SalesChart() {
  const { t } = useLanguage();
  const today = format(new Date(), 'yyyy-MM-dd');

  const { data: todayReport, isLoading } = useQuery({
    queryKey: ["/api/daily-sales", "breakdown", today],
    queryFn: async () => {
      const response = await fetch(`/api/daily-sales?date=${today}`);
      if (!response.ok) return null;
      const data = await response.json();
      return data.length > 0 ? data[0] : null;
    }
  });

  if (isLoading) {
    return (
      <Card className="border-gray-200">
        <CardHeader>
          <CardTitle className="text-lg font-semibold text-gray-900">
            {t.chart.salesByChannel}
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="animate-pulse space-y-4">
            {[1,2,3].map(i => (
              <div key={i} className="h-8 bg-gray-200 rounded"></div>
            ))}
          </div>
        </CardContent>
      </Card>
    );
  }

  if (!todayReport) {
    return (
      <Card className="border-gray-200">
        <CardHeader>
          <CardTitle className="text-lg font-semibold text-gray-900">
            {t.chart.salesByChannel}
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-center py-8 text-gray-500">
            <p className="text-sm">{t.chart.noSalesData}</p>
            <p className="text-xs mt-1">
              <a href="/daily-sales" className="text-bk-red hover:text-red-700">
                {t.chart.recordToSeeChart}
              </a>
            </p>
          </div>
        </CardContent>
      </Card>
    );
  }

  const dineIn = parseFloat(todayReport.dineIn) || 0;
  const takeAway = parseFloat(todayReport.takeAway) || 0;
  const delivery = parseFloat(todayReport.delivery) || 0;
  const total = dineIn + takeAway + delivery;

  const salesData = total > 0 ? [
    { 
      channel: t.chart.dineIn, 
      amount: dineIn, 
      percentage: (dineIn / total) * 100, 
      color: "bg-bk-red" 
    },
    { 
      channel: t.chart.takeAway, 
      amount: takeAway, 
      percentage: (takeAway / total) * 100, 
      color: "bg-bk-gold" 
    },
    { 
      channel: t.chart.delivery, 
      amount: delivery, 
      percentage: (delivery / total) * 100, 
      color: "bg-bk-brown" 
    },
  ] : [];

  return (
    <Card className="border-gray-200">
      <CardHeader>
        <CardTitle className="text-lg font-semibold text-gray-900">
          {t.chart.salesByChannel}
        </CardTitle>
      </CardHeader>
      <CardContent>
        {salesData.length === 0 ? (
          <div className="text-center py-8 text-gray-500">
            <p className="text-sm">{t.chart.noSalesData}</p>
          </div>
        ) : (
          <div className="space-y-4">
            {salesData.map((item, index) => (
              <div key={index}>
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center space-x-2">
                    <div className={`w-3 h-3 rounded ${item.color}`} />
                    <span className="text-sm text-gray-700">{item.channel}</span>
                  </div>
                  <span className="text-sm font-medium">
                    ₿{item.amount.toLocaleString()} ({item.percentage.toFixed(1)}%)
                  </span>
                </div>
                <div className="bg-gray-100 rounded-full h-2">
                  <div 
                    className={`h-2 rounded-full ${item.color}`}
                    style={{ width: `${item.percentage}%` }}
                  />
                </div>
              </div>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  );
}
