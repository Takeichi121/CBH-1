import { Card, CardContent } from "@/components/ui/card";
import { TrendingUp, Receipt, Calendar, Star } from "lucide-react";
import { useQuery } from "@tanstack/react-query";
import { format, startOfMonth, endOfMonth } from "date-fns";
import { useLanguage } from "@/contexts/language-context";

export default function KPICards() {
  const { t, language } = useLanguage();
  const today = format(new Date(), 'yyyy-MM-dd');
  const monthStart = format(startOfMonth(new Date()), 'yyyy-MM-dd');
  const monthEnd = format(endOfMonth(new Date()), 'yyyy-MM-dd');

  const { data: todayReport } = useQuery({
    queryKey: ["/api/daily-sales", "today", today],
    queryFn: async () => {
      const response = await fetch(`/api/daily-sales?date=${today}`);
      if (!response.ok) return null;
      const data = await response.json();
      return data.length > 0 ? data[0] : null;
    }
  });

  const { data: monthlyReports } = useQuery({
    queryKey: ["/api/daily-sales", "monthly", monthStart, monthEnd],
    queryFn: async () => {
      const response = await fetch(`/api/daily-sales?dateFrom=${monthStart}&dateTo=${monthEnd}`);
      if (!response.ok) return [];
      return response.json();
    }
  });

  const monthlyStats = monthlyReports?.reduce((acc: any, report: any) => {
    acc.totalSales += parseFloat(report.actualSales) || 0;
    acc.totalTransactions += report.transactionCount || 0;
    acc.totalTarget += parseFloat(report.dailyTarget) || 0;
    if (report.gsi) {
      acc.gsiSum += parseFloat(report.gsi);
      acc.gsiCount += 1;
    }
    return acc;
  }, { totalSales: 0, totalTransactions: 0, totalTarget: 0, gsiSum: 0, gsiCount: 0 });

  const monthlyAchievement = monthlyStats?.totalTarget > 0 
    ? (monthlyStats.totalSales / monthlyStats.totalTarget) * 100 
    : 0;

  const averageGSI = monthlyStats?.gsiCount > 0 
    ? monthlyStats.gsiSum / monthlyStats.gsiCount 
    : null;

  const noDataText = language === 'th' ? 'ยังไม่มีข้อมูล' : 'No data';
  const targetText = language === 'th' ? 'เป้า' : 'Target';
  const targetPctText = language === 'th' ? 'เป้าหมาย' : 'Target';

  const getGSIRating = (gsi: number | null) => {
    if (gsi === null) return '';
    if (language === 'th') {
      return gsi >= 4.5 ? 'ดีเยี่ยม' : gsi >= 4.0 ? 'ดี' : 'ปรับปรุง';
    }
    return gsi >= 4.5 ? 'Excellent' : gsi >= 4.0 ? 'Good' : 'Improve';
  };

  const kpiData = [
    {
      title: t.kpi.dailySales,
      value: todayReport ? `₿${parseFloat(todayReport.actualSales).toLocaleString()}` : noDataText,
      change: todayReport ? `${targetText}: ₿${parseFloat(todayReport.dailyTarget).toLocaleString()}` : "",
      icon: TrendingUp,
      color: "text-gray-600",
      bgColor: "bg-gray-100"
    },
    {
      title: t.kpi.transactions, 
      value: todayReport ? todayReport.transactionCount.toLocaleString() : "-",
      change: "",
      icon: Receipt,
      color: "text-gray-600",
      bgColor: "bg-gray-100"
    },
    {
      title: t.kpi.mtdSales,
      value: monthlyStats ? `₿${monthlyStats.totalSales.toLocaleString()}` : noDataText,
      change: monthlyStats ? `${targetPctText}: ${monthlyAchievement.toFixed(1)}%` : "",
      icon: Calendar,
      color: monthlyAchievement >= 100 ? "text-green-600" : monthlyAchievement >= 90 ? "text-yellow-600" : "text-red-600",
      bgColor: monthlyAchievement >= 100 ? "bg-green-100" : monthlyAchievement >= 90 ? "bg-yellow-100" : "bg-red-100"
    },
    {
      title: t.kpi.gsiScore,
      value: averageGSI ? averageGSI.toFixed(1) : "-",
      change: getGSIRating(averageGSI),
      icon: Star,
      color: averageGSI !== null && averageGSI >= 4.5 ? "text-bk-gold" : averageGSI !== null && averageGSI >= 4.0 ? "text-green-600" : "text-gray-600",
      bgColor: averageGSI !== null && averageGSI >= 4.5 ? "bg-yellow-100" : averageGSI !== null && averageGSI >= 4.0 ? "bg-green-100" : "bg-gray-100"
    }
  ];

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
      {kpiData.map((kpi, index) => {
        const Icon = kpi.icon;
        return (
          <Card key={index} className="border-gray-200" data-testid={`kpi-card-${index}`}>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-gray-500 text-sm">{kpi.title}</p>
                  <p className="text-2xl font-bold text-gray-900">{kpi.value}</p>
                  {kpi.change && (
                    <p className={`text-sm ${kpi.color} mt-1`}>
                      {kpi.change}
                    </p>
                  )}
                </div>
                <div className={`w-12 h-12 ${kpi.bgColor} rounded-full flex items-center justify-center`}>
                  <Icon className={`w-6 h-6 ${kpi.color}`} />
                </div>
              </div>
            </CardContent>
          </Card>
        );
      })}
    </div>
  );
}
