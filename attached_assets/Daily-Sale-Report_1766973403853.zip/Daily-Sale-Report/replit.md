# Overview

This is a modern full-stack restaurant management dashboard application called "BK Grand Diamond" built for Burger King. The application provides comprehensive business intelligence features including daily sales reporting, performance metrics tracking, staff roster management, and real-time dashboard analytics. The system is designed to help restaurant managers monitor key performance indicators (KPIs), track sales across multiple channels (dine-in, takeaway, delivery), and manage operational efficiency metrics.

# User Preferences

Preferred communication style: Simple, everyday language.

# System Architecture

## Frontend Architecture

The client-side is built as a React Single Page Application (SPA) using TypeScript and Vite as the build tool. The architecture follows a component-based design pattern with:

- **UI Framework**: React 18 with functional components and hooks for modern development practices
- **State Management**: TanStack React Query for server state management and caching, eliminating the need for complex state management libraries
- **Routing**: Wouter for lightweight client-side routing with minimal bundle overhead
- **Styling**: Tailwind CSS with shadcn/ui component library for consistent design system and rapid UI development
- **Form Handling**: React Hook Form with Zod validation for type-safe form management and validation
- **Build Tool**: Vite with TypeScript support and hot module replacement for fast development cycles

The frontend implements a modern dashboard interface with KPI cards, charts, and data tables. It includes bilingual support (Thai/English) and responsive design optimized for both desktop and mobile devices.

## Backend Architecture

The server is built using Express.js with TypeScript in an ESM module format. The architecture follows RESTful API principles with:

- **Runtime**: Node.js with native ES modules for modern JavaScript features
- **Framework**: Express.js for HTTP server and API routing with middleware-based architecture
- **Data Layer**: Storage abstraction pattern with interface-based design for flexible data persistence
- **Validation**: Zod schemas for request/response validation ensuring type safety across the stack
- **Error Handling**: Centralized error middleware with proper HTTP status codes and structured error responses
- **Development Tools**: Custom Vite integration for seamless development experience with HMR

The API provides endpoints for daily sales reports, store settings, and dashboard analytics. The current implementation uses in-memory storage with a clear interface for easy migration to persistent databases.

## Database Design

The application is configured to use PostgreSQL with Drizzle ORM for type-safe database operations:

- **ORM**: Drizzle with full TypeScript integration and compile-time query validation
- **Schema Management**: Code-first approach with automatic migrations using drizzle-kit
- **Data Models**: Comprehensive schema including users, daily sales reports, store settings, and session storage
- **Database Provider**: Configured for Neon PostgreSQL with connection pooling support
- **Migration Strategy**: Structured migration system with version control and rollback capabilities

Key tables include users for authentication, daily_sales_reports for comprehensive sales tracking, store_settings for configuration management, and sessions for secure authentication state.

## Form Persistence & UX Enhancements

The application includes sophisticated user experience features:

- **Auto-save Functionality**: Debounced form persistence to localStorage preventing data loss
- **Unsaved Changes Detection**: Browser beforeunload warnings to prevent accidental data loss
- **Draft Management**: Automatic draft restoration with timestamp tracking
- **Mobile Responsiveness**: Optimized layouts for various screen sizes with touch-friendly interactions

# External Dependencies

## UI Components & Styling
- **Radix UI**: Comprehensive set of unstyled, accessible components (@radix-ui/react-*)
- **Tailwind CSS**: Utility-first CSS framework for rapid UI development
- **shadcn/ui**: Pre-built component library with consistent design patterns
- **Lucide React**: Modern icon library with consistent styling

## Development & Build Tools
- **Vite**: Fast build tool with HMR and optimized production builds
- **TypeScript**: Static type checking and enhanced developer experience
- **Drizzle Kit**: Database migration and schema management tooling
- **ESBuild**: Fast JavaScript bundler for production builds

## Database & ORM
- **Neon Database**: Serverless PostgreSQL with automatic scaling
- **Drizzle ORM**: Type-safe database toolkit with SQL-like syntax
- **PostgreSQL**: Relational database for structured data storage

## Form & Validation
- **React Hook Form**: Performant forms with minimal re-renders
- **Zod**: TypeScript-first schema validation library
- **Hookform Resolvers**: Integration between React Hook Form and Zod

## Development Environment
- **Replit Integration**: Custom plugins for seamless Replit development experience
- **Runtime Error Overlay**: Enhanced error reporting during development
- **Cartographer**: Development tooling for better debugging experience