\
const express = require("express");
const helmet = require("helmet");
const path = require("path");
const api = require("./src/logic");
const { initDb } = require("./src/db");

const PORT = Number(process.env.PORT || 3000);
initDb();

const app = express();
app.use(helmet({ contentSecurityPolicy: false }));
app.use(express.json({ limit: "1mb" }));
app.use(express.urlencoded({ extended: true }));
app.use("/public", express.static(path.join(__dirname, "public")));

function sanitizePage(p){
  p = String(p || "login").trim().toLowerCase();
  const allow = { login:1, register:1, work:1, roster:1, settings:1 };
  return allow[p] ? p : "login";
}

app.get("/", (req, res) => {
  const page = sanitizePage(req.query.page || "login");
  res.setHeader("Content-Type", "text/html; charset=utf-8");
  if(page==="login") return res.send(api.htmlLogin());
  if(page==="register") return res.send(api.htmlRegister());
  if(page==="work") return res.send(api.htmlWork());
  if(page==="roster") return res.send(api.htmlRoster());
  if(page==="settings") return res.send(api.htmlSettings());
  return res.send(api.htmlLogin());
});

// API
app.post("/api/ping", (req,res)=> res.json(api.ping()));
app.post("/api/setup", (req,res)=> res.json(api.setup()));

app.post("/api/login", (req,res)=> res.json(api.login(req.body.username, req.body.password)));
app.post("/api/validate", (req,res)=> res.json(api.validate(req.body.token)));
app.post("/api/logout", (req,res)=> res.json(api.logout(req.body.token)));

app.post("/api/registerStaff", (req,res)=> res.json(api.registerStaff(
  req.body.fullName, req.body.nickName, req.body.phone, req.body.email, req.body.password
)));
app.post("/api/registerManager", (req,res)=> res.json(api.registerManager(
  req.body.fullName, req.body.nickName, req.body.phone, req.body.email, req.body.password, req.body.verifyCode
)));

app.post("/api/getSettings", (req,res)=> res.json(api.getSettings(req.body.token)));
app.post("/api/updateSettings", (req,res)=> res.json(api.updateSettings(req.body.token, req.body.capacity)));

app.post("/api/getMyWeek", (req,res)=> res.json(api.getMyWeek(req.body.token, req.body.anyDate)));
app.post("/api/bookMyShift", (req,res)=> res.json(api.bookMyShift(
  req.body.token, req.body.date, req.body.shiftGroup, req.body.startTime, req.body.note
)));
app.post("/api/cancelMyShift", (req,res)=> res.json(api.cancelMyShift(req.body.token, req.body.date)));

app.post("/api/getRosterWeek", (req,res)=> res.json(api.getRosterWeek(req.body.token, req.body.anyDate)));
app.post("/api/setShiftForUser", (req,res)=> res.json(api.setShiftForUser(
  req.body.token, req.body.username, req.body.date, req.body.shiftGroup, req.body.startTime, req.body.note
)));
app.post("/api/deleteShiftForUser", (req,res)=> res.json(api.deleteShiftForUser(req.body.token, req.body.username, req.body.date)));

app.listen(PORT, () => {
  console.log("BK Schedule running on port", PORT);
  console.log("Open: http://localhost:"+PORT+"/?page=login");
});
