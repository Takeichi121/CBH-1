# BK Work Schedule (Replit)

## Run
- Import into Replit, then Run.
- First time only: initialize DB (creates default accounts + capacities)
  - Open the app, then open DevTools console and run:
    fetch("/api/setup",{method:"POST"}).then(r=>r.json()).then(console.log)

## Pages
- /?page=login
- /?page=register
- /?page=work
- /?page=roster
- /?page=settings

## Default accounts (after setup)
- admin / 1234
- manager / 1234

## Data
- SQLite file: data.db
- You can set secrets in Replit:
  - SALT, MANAGER_VERIFY_CODE, BRANCH_NAME, CREATOR_CREDIT
