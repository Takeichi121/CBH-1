\
const Database = require("better-sqlite3");
const path = require("path");

const DB_PATH = process.env.DB_PATH || path.join(__dirname, "..", "data.db");
const db = new Database(DB_PATH);

function initDb(){
  db.pragma("journal_mode = WAL");
  db.exec(`
CREATE TABLE IF NOT EXISTS users (
  username TEXT PRIMARY KEY,
  passhash TEXT NOT NULL,
  role TEXT NOT NULL,
  fullName TEXT,
  nickName TEXT,
  phone TEXT,
  email TEXT,
  position TEXT,
  active INTEGER NOT NULL DEFAULT 1,
  createdAt TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS shifts (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  date TEXT NOT NULL,
  username TEXT NOT NULL,
  fullName TEXT,
  role TEXT,
  shiftGroup TEXT NOT NULL,
  startTime TEXT NOT NULL,
  endTime TEXT NOT NULL,
  note TEXT,
  createdAt TEXT NOT NULL,
  updatedAt TEXT NOT NULL,
  updatedBy TEXT,
  UNIQUE(username, date)
);
CREATE TABLE IF NOT EXISTS config (
  key TEXT PRIMARY KEY,
  value TEXT NOT NULL,
  updatedAt TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS systemlog (
  ts TEXT NOT NULL,
  action TEXT NOT NULL,
  byUser TEXT,
  detail TEXT
);
CREATE TABLE IF NOT EXISTS sessions (
  token TEXT PRIMARY KEY,
  username TEXT NOT NULL,
  expiresAt INTEGER NOT NULL
);
  `);
}

function q(sql, params){
  const stmt = db.prepare(sql);
  if (stmt.reader) return stmt.all(params || {});
  return stmt.run(params || {});
}

module.exports = { db, initDb, q };
