import { Link, useLocation } from "wouter";
import { Crown, BarChart3, Edit, FileText, Settings } from "lucide-react";
import { cn } from "@/lib/utils";
import { useFormPersistence } from "@/hooks/use-form-persistence";
import { useLanguage } from "@/contexts/language-context";

interface SidebarProps {
  isOpen: boolean;
  onToggle: (open: boolean) => void;
}

export default function Sidebar({ isOpen, onToggle }: SidebarProps) {
  const [location] = useLocation();
  const { hasDraft } = useFormPersistence('daily-sales-form');
  const { t } = useLanguage();

  const navigation = [
    { name: t.nav.dashboard, href: "/dashboard", icon: BarChart3 },
    { name: t.nav.dailySales, href: "/daily-sales", icon: Edit },
    { name: t.nav.reports, href: "/reports", icon: FileText },
    { name: t.nav.settings, href: "/settings", icon: Settings },
  ];

  return (
    <>
      {isOpen && (
        <div 
          className="fixed inset-0 z-40 lg:hidden bg-gray-500 bg-opacity-75"
          onClick={() => onToggle(false)}
        />
      )}
      
      <div className={cn(
        "fixed inset-y-0 left-0 z-50 w-64 bg-white shadow-lg border-r border-gray-200 transition-transform duration-200 ease-in-out lg:translate-x-0",
        isOpen ? "translate-x-0" : "-translate-x-full"
      )}>
        <div className="flex flex-col h-full">
          <div className="flex items-center justify-center h-16 bg-bk-red">
            <div className="flex items-center space-x-2">
              <div className="w-8 h-8 bg-bk-gold rounded-full flex items-center justify-center">
                <Crown className="w-4 h-4 text-bk-red" />
              </div>
              <div className="text-white font-bold text-lg">BK Grand Diamond</div>
            </div>
          </div>

          <nav className="flex-1 px-4 py-6 space-y-2">
            {navigation.map((item, index) => {
              const Icon = item.icon;
              const isActive = location === item.href || 
                (item.href === "/dashboard" && location === "/");
              
              return (
                <Link key={index} href={item.href}>
                  <div 
                    className={cn(
                      "flex items-center px-4 py-3 rounded-lg transition-colors cursor-pointer",
                      isActive
                        ? "text-bk-red bg-red-50"
                        : "text-gray-700 hover:bg-gray-100"
                    )}
                    data-testid={`nav-item-${item.href.replace('/', '')}`}
                  >
                    <Icon className="w-5 h-5 mr-3" />
                    <span>{item.name}</span>
                    {item.href === "/daily-sales" && hasDraft && (
                      <div className="ml-auto">
                        <span className="w-2 h-2 bg-bk-gold rounded-full block animate-pulse" />
                      </div>
                    )}
                  </div>
                </Link>
              );
            })}
          </nav>

          <div className="px-4 py-4 border-t border-gray-200">
            <div className="flex items-center space-x-3">
              <div className="w-8 h-8 bg-bk-gold rounded-full flex items-center justify-center">
                <span className="text-bk-red font-medium text-sm">CJ</span>
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-sm font-medium text-gray-900">Chanon Jaimool</p>
                <p className="text-xs text-gray-500">{t.sidebar.manager}</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}
