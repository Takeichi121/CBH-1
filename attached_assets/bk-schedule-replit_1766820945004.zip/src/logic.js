\
const crypto = require("crypto");
const fs = require("fs");
const path = require("path");
const { q } = require("./db");

const BRANCH_NAME = process.env.BRANCH_NAME || "Grand Diamond";
const CREATOR_CREDIT = process.env.CREATOR_CREDIT || "Chan. J (Chanon Jaimool)";
const SALT = process.env.SALT || "BK_SALT_v2_change_me";
const SESSION_TTL_SECONDS = Number(process.env.SESSION_TTL_SECONDS || 60 * 60 * 6);
const MANAGER_VERIFY_CODE = (process.env.MANAGER_VERIFY_CODE || "bk1040").toLowerCase();

const DEFAULT_POSITION_STAFF = "Service Staff";
const DEFAULT_POSITION_MANAGER = "Manager";

const SHIFT_GROUPS = [
  { key: "open",   label: "Open",       windowStart: "00:00", windowEnd: "11:00", main: "07:00" },
  { key: "lunch",  label: "Lunch",      windowStart: "12:00", windowEnd: "14:00", main: "13:00" },
  { key: "dinner", label: "Dinner",     windowStart: "15:00", windowEnd: "18:00", main: "15:00" },
  { key: "late",   label: "Late Night", windowStart: "20:00", windowEnd: "23:00", main: "22:00" },
];

const DEFAULT_CAPACITY = { open: 4, lunch: 4, dinner: 4, late: 4 };

function nowIso(){ return new Date().toISOString(); }
function escHtml(s){
  return String(s || "").replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
}
function sha256hex(s){ return crypto.createHash("sha256").update(String(s), "utf8").digest("hex"); }
function hashPass(password){ return sha256hex(SALT + "::" + String(password || "")); }

function isValidDate(ymd){ return /^\d{4}-\d{2}-\d{2}$/.test(String(ymd || "")); }
function parseHHMM(t){
  const m = String(t || "").match(/^(\d{2}):(\d{2})$/);
  if(!m) return null;
  const hh = Number(m[1]), mm = Number(m[2]);
  if(hh<0||hh>23||mm<0||mm>59) return null;
  return hh*60+mm;
}
function isTimeInWindow(t, start, end){
  const a=parseHHMM(t), s=parseHHMM(start), e=parseHHMM(end);
  if(a==null||s==null||e==null) return false;
  return a>=s && a<=e;
}
function addMinutesToHHMM(t, mins){
  const a = parseHHMM(t);
  if(a==null) return "";
  let x = a + Number(mins||0);
  x = ((x % (24*60)) + (24*60)) % (24*60);
  const hh = Math.floor(x/60), mm = x%60;
  return String(hh).padStart(2,"0")+":"+String(mm).padStart(2,"0");
}

// System closed: Tue >=12:00 and all day Wed
function isSystemClosed(){
  const parts = new Intl.DateTimeFormat("en-GB", { timeZone:"Asia/Bangkok", hour:"2-digit", minute:"2-digit", weekday:"short", hour12:false }).formatToParts(new Date());
  const hh = parts.find(p=>p.type==="hour")?.value || "00";
  const mm = parts.find(p=>p.type==="minute")?.value || "00";
  const wd = parts.find(p=>p.type==="weekday")?.value || "Mon";
  const map = { Mon:1, Tue:2, Wed:3, Thu:4, Fri:5, Sat:6, Sun:7 };
  const d = map[wd] || 1;
  const hhmm = `${hh}:${mm}`;
  if (d === 2) return hhmm >= "12:00";
  if (d === 3) return true;
  return false;
}

function log(action, byUser, detail){
  try{
    q("INSERT INTO systemlog(ts, action, byUser, detail) VALUES(@ts,@a,@b,@d)", {
      ts: nowIso(), a: String(action), b: String(byUser||""), d: String(detail||"")
    });
  }catch(e){}
}

function getUser(username){
  return q("SELECT * FROM users WHERE username=@u", { u: String(username||"").toLowerCase() })[0] || null;
}
function addUser(username, password, role, fullName, nickName, phone, email, position, active){
  username = String(username).toLowerCase();
  q(`INSERT INTO users(username, passhash, role, fullName, nickName, phone, email, position, active, createdAt)
     VALUES(@u,@p,@r,@fn,@nn,@ph,@em,@pos,@ac,@ca)`,{
    u: username, p: hashPass(password), r: role || "staff",
    fn: fullName || "", nn: nickName || "", ph: phone || "", em: email || "",
    pos: position || DEFAULT_POSITION_STAFF, ac: active ? 1 : 0, ca: nowIso()
  });
}
function pickUser(u){
  return { username: u.username, role: u.role, fullName: u.fullName || u.username, nickName: u.nickName||"", phone:u.phone||"", email:u.email||"", position:u.position||"" };
}

function createSession(username){
  const token = crypto.randomUUID().replace(/-/g,"");
  const expiresAt = Math.floor(Date.now()/1000) + SESSION_TTL_SECONDS;
  q("INSERT INTO sessions(token, username, expiresAt) VALUES(@t,@u,@e)", { t: token, u: String(username).toLowerCase(), e: expiresAt });
  return token;
}
function validate(token){
  token = String(token||"").trim();
  if(!token) return { ok:false };
  const row = q("SELECT username, expiresAt FROM sessions WHERE token=@t", { t: token })[0];
  if(!row) return { ok:false };
  const now = Math.floor(Date.now()/1000);
  if(now > Number(row.expiresAt||0)){ q("DELETE FROM sessions WHERE token=@t",{t:token}); return { ok:false }; }
  const u = getUser(row.username);
  if(!u || !u.active) return { ok:false };
  return { ok:true, user: pickUser(u) };
}
function logout(token){
  token = String(token||"").trim();
  if(token) q("DELETE FROM sessions WHERE token=@t", { t: token });
  return { ok:true };
}

function getConfigAll(){
  const rows = q("SELECT key, value FROM config", {});
  const o = {};
  rows.forEach(r => { o[String(r.key)] = String(r.value); });
  return o;
}
function setConfig(key, value){
  const now = nowIso();
  const exists = q("SELECT key FROM config WHERE key=@k", { k: String(key) })[0];
  if(!exists) q("INSERT INTO config(key,value,updatedAt) VALUES(@k,@v,@u)", { k:String(key), v:String(value), u:now });
  else q("UPDATE config SET value=@v, updatedAt=@u WHERE key=@k", { k:String(key), v:String(value), u:now });
}
function getCapacity(){
  const cfg = getConfigAll();
  const out = {};
  Object.keys(DEFAULT_CAPACITY).forEach(k => { out[k] = Number(cfg["cap_"+k] || DEFAULT_CAPACITY[k]); });
  return out;
}

function generateUsernameBase(fullName){
  const s = String(fullName||"").trim().replace(/\s+/g," ");
  const parts = s.split(" ");
  if(parts.length < 2) return "";
  const first = parts[0].replace(/\s/g,"").slice(0,3);
  const last = parts[parts.length-1].replace(/\s/g,"").slice(0,3);
  if(!first||!last) return "";
  return (first+last).toLowerCase();
}
function allocateUsername(base6){
  base6 = String(base6||"").trim().toLowerCase();
  if(!base6) return "";
  for(let i=1;i<=999;i++){
    const u = base6 + String(i).padStart(3,"0");
    if(!getUser(u)) return u;
  }
  return "";
}

function getWeekRangeTuesday(anyDate){
  const base = (anyDate && isValidDate(anyDate)) ? new Date(anyDate+"T00:00:00+07:00") : new Date();
  const parts = new Intl.DateTimeFormat("en-GB", { timeZone:"Asia/Bangkok", year:"numeric", month:"2-digit", day:"2-digit", weekday:"short" }).formatToParts(base);
  const yyyy = parts.find(p=>p.type==="year")?.value;
  const mm = parts.find(p=>p.type==="month")?.value;
  const dd = parts.find(p=>p.type==="day")?.value;
  const wd = parts.find(p=>p.type==="weekday")?.value || "Mon";
  const map = { Mon:1, Tue:2, Wed:3, Thu:4, Fri:5, Sat:6, Sun:7 };
  const u = map[wd] || 1;

  const d0 = new Date(`${yyyy}-${mm}-${dd}T00:00:00+07:00`);
  const delta = (u >= 2) ? (u - 2) : (7 - (2 - u));
  const start = new Date(d0.getTime());
  start.setDate(start.getDate() - delta);

  const days = [];
  for(let i=0;i<7;i++){
    const x = new Date(start.getTime());
    x.setDate(x.getDate()+i);
    days.push(x.toISOString().slice(0,10));
  }
  return { start: days[0], end: days[6], days };
}
function getShiftsInRange(fromYMD, toYMD){
  return q("SELECT * FROM shifts WHERE date >= @f AND date <= @t ORDER BY date ASC", { f: fromYMD, t: toYMD });
}
function getShiftByUserDate(username, date){
  return q("SELECT * FROM shifts WHERE username=@u AND date=@d", { u: String(username||"").toLowerCase(), d: String(date) })[0] || null;
}
function countShift(date, shiftGroup){
  const r = q("SELECT COUNT(1) as c FROM shifts WHERE date=@d AND shiftGroup=@g", { d:String(date), g:String(shiftGroup) })[0];
  return Number(r?.c || 0);
}
function upsertShift(date, username, fullName, role, shiftGroup, startTime, endTime, note, by){
  const now = nowIso();
  const existing = getShiftByUserDate(username, date);
  if(!existing){
    q(`INSERT INTO shifts(date, username, fullName, role, shiftGroup, startTime, endTime, note, createdAt, updatedAt, updatedBy)
       VALUES(@d,@u,@fn,@r,@g,@st,@et,@no,@ca,@ua,@ub)`, {
      d:String(date), u:String(username).toLowerCase(), fn:fullName||"", r:role||"",
      g:String(shiftGroup), st:String(startTime), et:String(endTime), no:note||"",
      ca: now, ua: now, ub: by||"system"
    });
  } else {
    q(`UPDATE shifts SET fullName=@fn, role=@r, shiftGroup=@g, startTime=@st, endTime=@et, note=@no, updatedAt=@ua, updatedBy=@ub
       WHERE username=@u AND date=@d`, {
      d:String(date), u:String(username).toLowerCase(), fn:fullName||"", r:role||"",
      g:String(shiftGroup), st:String(startTime), et:String(endTime), no:note||"",
      ua: now, ub: by||"system"
    });
  }
}
function deleteShift(username, date){
  const r = q("DELETE FROM shifts WHERE username=@u AND date=@d", { u:String(username).toLowerCase(), d:String(date) });
  return (r.changes || 0) > 0;
}

function ping(){ return { ok:true, ts: nowIso(), closed: isSystemClosed(), branch: BRANCH_NAME }; }

function setup(){
  const cfg = getConfigAll();
  Object.keys(DEFAULT_CAPACITY).forEach(k => { if(!("cap_"+k in cfg)) setConfig("cap_"+k, String(DEFAULT_CAPACITY[k])); });

  if(!getUser("admin")){ addUser("admin","1234","admin","Admin","","","","Admin", true); log("setup_create_admin","system","admin created"); }
  if(!getUser("manager")){ addUser("manager","1234","manager","Manager","","","",DEFAULT_POSITION_MANAGER, true); log("setup_create_manager","system","manager created"); }

  log("setup_ok","system","setup completed");
  return { ok:true, message:"setup ok" };
}

function login(username, password){
  if(isSystemClosed()) return { ok:false, message:"ระบบปิดช่วงนี้" };
  username = String(username||"").trim().toLowerCase();
  password = String(password||"");
  if(!username || !password) return { ok:false, message:"กรอกให้ครบ" };
  const u = getUser(username);
  if(!u || !u.active) return { ok:false, message:"ไม่พบบัญชี/ถูกปิดใช้งาน" };
  if(hashPass(password) !== u.passhash) return { ok:false, message:"รหัสผ่านไม่ถูก" };
  const token = createSession(u.username);
  log("login_ok", u.username, "role="+u.role);
  return { ok:true, token, user: pickUser(u) };
}

function registerStaff(fullName, nickName, phone, email, password){
  if(isSystemClosed()) return { ok:false, message:"ระบบปิดช่วงนี้" };
  fullName = String(fullName||"").trim();
  nickName = String(nickName||"").trim();
  phone = String(phone||"").trim();
  email = String(email||"").trim();
  password = String(password||"");
  if(!fullName || !password || !email) return { ok:false, message:"ต้องกรอก ชื่อ-สกุล / Email / Password" };
  const base = generateUsernameBase(fullName);
  const username = allocateUsername(base);
  if(!username) return { ok:false, message:"สร้าง username ไม่สำเร็จ" };
  addUser(username, password, "staff", fullName, nickName, phone, email, DEFAULT_POSITION_STAFF, true);
  log("register_staff", username, "fullName="+fullName);
  return { ok:true, username };
}

function registerManager(fullName, nickName, phone, email, password, verifyCode){
  if(isSystemClosed()) return { ok:false, message:"ระบบปิดช่วงนี้" };
  verifyCode = String(verifyCode||"").trim().toLowerCase();
  if(verifyCode !== MANAGER_VERIFY_CODE) return { ok:false, message:"รหัสยืนยันไม่ถูก" };
  fullName = String(fullName||"").trim();
  nickName = String(nickName||"").trim();
  phone = String(phone||"").trim();
  email = String(email||"").trim();
  password = String(password||"");
  if(!fullName || !password || !email) return { ok:false, message:"ต้องกรอก ชื่อ-สกุล / Email / Password" };
  const base = generateUsernameBase(fullName);
  const username = allocateUsername(base);
  if(!username) return { ok:false, message:"สร้าง username ไม่สำเร็จ" };
  addUser(username, password, "manager", fullName, nickName, phone, email, DEFAULT_POSITION_MANAGER, true);
  log("register_manager", username, "fullName="+fullName);
  return { ok:true, username };
}

function getSettings(token){
  const v = validate(token);
  if(!v.ok) return { ok:false, message:"session หมดอายุ/ไม่ถูกต้อง" };
  if(!(v.user.role==="admin" || v.user.role==="manager")) return { ok:false, message:"สิทธิ์ไม่พอ" };
  return { ok:true, capacity: getCapacity(), groups: SHIFT_GROUPS };
}
function updateSettings(token, capacityObj){
  const v = validate(token);
  if(!v.ok) return { ok:false, message:"session หมดอายุ/ไม่ถูกต้อง" };
  if(!(v.user.role==="admin" || v.user.role==="manager")) return { ok:false, message:"สิทธิ์ไม่พอ" };
  capacityObj = capacityObj || {};
  Object.keys(DEFAULT_CAPACITY).forEach(k=>{
    const n = Number(capacityObj[k]);
    if(!isFinite(n) || n<0 || n>99) return;
    setConfig("cap_"+k, String(Math.floor(n)));
  });
  log("settings_update", v.user.username, JSON.stringify(capacityObj));
  return { ok:true };
}

function getMyWeek(token, anyDate){
  const v = validate(token);
  if(!v.ok) return { ok:false, message:"session หมดอายุ/ไม่ถูกต้อง" };
  const wk = getWeekRangeTuesday(anyDate);
  const shifts = getShiftsInRange(wk.start, wk.end);
  const mine = shifts.filter(s => String(s.username).toLowerCase() === v.user.username);
  return { ok:true, weekStart: wk.start, days: wk.days, items: mine, capacity: getCapacity(), groups: SHIFT_GROUPS, closed: isSystemClosed(), user: v.user };
}

function bookMyShift(token, date, shiftGroup, startTime, note){
  const v = validate(token);
  if(!v.ok) return { ok:false, message:"session หมดอายุ/ไม่ถูกต้อง" };
  if(isSystemClosed()) return { ok:false, message:"ระบบปิดช่วงนี้" };
  if(v.user.role==="admin" || v.user.role==="manager") return { ok:false, message:"Admin/Manager ไม่ต้องลงกะ" };

  date = String(date||"").trim();
  shiftGroup = String(shiftGroup||"").trim();
  startTime = String(startTime||"").trim();
  note = String(note||"").trim();

  if(!date || !shiftGroup || !startTime) return { ok:false, message:"กรอกให้ครบ" };
  if(!isValidDate(date)) return { ok:false, message:"วันที่ไม่ถูก" };
  const g = SHIFT_GROUPS.find(x=>x.key===shiftGroup);
  if(!g) return { ok:false, message:"กะไม่ถูก" };
  if(!isTimeInWindow(startTime, g.windowStart, g.windowEnd)) return { ok:false, message:"เวลาเริ่มไม่อยู่ในช่วงกะ" };

  const cap = getCapacity();
  if(countShift(date, shiftGroup) >= Number(cap[shiftGroup])) return { ok:false, message:"กะนี้เต็มแล้ว" };
  if(getShiftByUserDate(v.user.username, date)) return { ok:false, message:"คุณมีตารางงานวันนั้นแล้ว" };

  const endTime = addMinutesToHHMM(startTime, 9*60);
  upsertShift(date, v.user.username, v.user.fullName, v.user.role, shiftGroup, startTime, endTime, note, v.user.username);
  log("book_shift", v.user.username, date+" "+shiftGroup+" "+startTime);
  return { ok:true };
}

function cancelMyShift(token, date){
  const v = validate(token);
  if(!v.ok) return { ok:false, message:"session หมดอายุ/ไม่ถูกต้อง" };
  if(isSystemClosed()) return { ok:false, message:"ระบบปิดช่วงนี้" };
  date = String(date||"").trim();
  if(!date || !isValidDate(date)) return { ok:false, message:"วันที่ไม่ถูก" };
  const ok = deleteShift(v.user.username, date);
  if(!ok) return { ok:false, message:"ไม่พบรายการ" };
  log("cancel_my_shift", v.user.username, date);
  return { ok:true };
}

function getRosterWeek(token, anyDate){
  const v = validate(token);
  if(!v.ok) return { ok:false, message:"session หมดอายุ/ไม่ถูกต้อง" };
  const wk = getWeekRangeTuesday(anyDate);
  const shifts = getShiftsInRange(wk.start, wk.end);

  const users = q("SELECT username, fullName, position, nickName FROM users WHERE role='staff' AND active=1 ORDER BY fullName ASC", {})
    .map(u => ({ username: u.username, fullName: u.fullName, position: u.position, nickName: u.nickName || "" }));

  const map = {};
  shifts.forEach(s => { map[String(s.username).toLowerCase()+"|"+String(s.date)] = s; });

  return { ok:true, weekStart: wk.start, days: wk.days, users, map, groups: SHIFT_GROUPS, capacity: getCapacity(), canManage: (v.user.role==="admin"||v.user.role==="manager"), closed: isSystemClosed(), me: v.user };
}

function setShiftForUser(token, username, date, shiftGroup, startTime, note){
  const v = validate(token);
  if(!v.ok) return { ok:false, message:"session หมดอายุ/ไม่ถูกต้อง" };
  if(!(v.user.role==="admin" || v.user.role==="manager")) return { ok:false, message:"สิทธิ์ไม่พอ" };
  if(isSystemClosed()) return { ok:false, message:"ระบบปิดช่วงนี้" };

  username = String(username||"").trim().toLowerCase();
  date = String(date||"").trim();
  shiftGroup = String(shiftGroup||"").trim();
  startTime = String(startTime||"").trim();
  note = String(note||"").trim();

  if(!username || !date || !shiftGroup || !startTime) return { ok:false, message:"กรอกให้ครบ" };
  if(!isValidDate(date)) return { ok:false, message:"วันที่ไม่ถูก" };

  const user = getUser(username);
  if(!user || user.role!=="staff" || !user.active) return { ok:false, message:"ไม่พบบุคลากร" };

  const g = SHIFT_GROUPS.find(x=>x.key===shiftGroup);
  if(!g) return { ok:false, message:"กะไม่ถูก" };
  if(!isTimeInWindow(startTime, g.windowStart, g.windowEnd)) return { ok:false, message:"เวลาเริ่มไม่อยู่ในช่วงกะ" };

  const existing = getShiftByUserDate(username, date);
  if(!existing || String(existing.shiftGroup)!==shiftGroup){
    const cap = getCapacity();
    if(countShift(date, shiftGroup) >= Number(cap[shiftGroup])) return { ok:false, message:"กะนี้เต็มแล้ว" };
  }

  const endTime = addMinutesToHHMM(startTime, 9*60);
  upsertShift(date, username, user.fullName, user.role, shiftGroup, startTime, endTime, note, v.user.username);
  log("manager_set_shift", v.user.username, username+" "+date+" "+shiftGroup+" "+startTime);
  return { ok:true };
}

function deleteShiftForUser(token, username, date){
  const v = validate(token);
  if(!v.ok) return { ok:false, message:"session หมดอายุ/ไม่ถูกต้อง" };
  if(!(v.user.role==="admin" || v.user.role==="manager")) return { ok:false, message:"สิทธิ์ไม่พอ" };
  if(isSystemClosed()) return { ok:false, message:"ระบบปิดช่วงนี้" };
  username = String(username||"").trim().toLowerCase();
  date = String(date||"").trim();
  if(!username || !isValidDate(date)) return { ok:false, message:"ข้อมูลไม่ถูก" };
  const ok = deleteShift(username, date);
  if(!ok) return { ok:false, message:"ไม่พบรายการ" };
  log("manager_delete_shift", v.user.username, username+" "+date);
  return { ok:true };
}

/* ===== HTML pages (inline) ===== */
const css = fs.readFileSync(path.join(__dirname, "..", "public", "app.css"), "utf8");
function baseHtml(title, body, script){
  return `<!doctype html><html lang="th"><head>
  <meta charset="utf-8"/><meta name="viewport" content="width=device-width, initial-scale=1"/>
  <title>${escHtml(title)}</title><style>${css}</style></head><body>${body}<script>${script||""}</script></body></html>`;
}

function htmlLogin(){
  const body = `
<div class="wrap wrapNarrow">
  <div class="header">
    <div class="brand"><div class="logo"></div><div>
      <div class="h1">BK ตารางงาน • ${escHtml(BRANCH_NAME)}</div><div class="h2"></div></div></div>
    <div id="who" class="pill">ยังไม่ได้เข้าสู่ระบบ</div>
  </div>
  <div class="card"><div class="inner">
    <div class="title">เข้าสู่ระบบ</div>
    <div class="row">
      <div><label>Username</label><input id="u" autocomplete="username"/></div>
      <div><label>Password</label><input id="p" type="password" autocomplete="current-password"/></div>
    </div>
    <div class="actions">
      <button class="btn btnPrimary" onclick="doLogin()">เข้าสู่ระบบ</button>
      <button class="btn btnGhost" onclick="nav('register')">ลงทะเบียน</button>
    </div>
    <div id="st" class="status"></div>
    <div class="footer"><div>Branch: ${escHtml(BRANCH_NAME)}</div><div>Created by ${escHtml(CREATOR_CREDIT)}</div></div>
  </div></div>
</div>`;
  const script = `
let TOKEN = localStorage.getItem("BK_TOKEN") || "";
function nav(page){ location.href = location.pathname + "?page=" + encodeURIComponent(page); }
function setStatus(msg, ok){ const el=document.getElementById("st"); el.className="status "+(ok?"ok":"bad"); el.textContent=msg||""; }
async function api(path, payload){ const res=await fetch("/api/"+path,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(payload||{})}); return res.json(); }
(async function boot(){ if(TOKEN){ try{ const r=await api("validate",{token:TOKEN}); if(r.ok) nav("work"); else {localStorage.removeItem("BK_TOKEN"); TOKEN="";} }catch(e){ localStorage.removeItem("BK_TOKEN"); TOKEN=""; } } })();
async function doLogin(){
  setStatus("กำลังล็อกอิน...", true);
  const u=document.getElementById("u").value.trim(); const p=document.getElementById("p").value;
  const r=await api("login",{username:u,password:p});
  if(!r.ok){ setStatus(r.message||"ล็อกอินไม่สำเร็จ", false); return; }
  localStorage.setItem("BK_TOKEN", r.token);
  nav("work");
}`;
  return baseHtml("Login", body, script);
}

function htmlRegister(){
  const body = `
<div class="wrap wrapNarrow">
  <div class="header">
    <div class="brand"><div class="logo"></div><div>
      <div class="h1">BK ตารางงาน • ${escHtml(BRANCH_NAME)}</div><div class="h2"></div></div></div>
    <div class="pill">สมัครใช้งาน</div>
  </div>

  <div class="card"><div class="inner">
    <div class="navbar">
      <button id="btnStaff" class="navbtn active" onclick="show('staff')">Register Staff</button>
      <button id="btnMgr" class="navbtn" onclick="show('manager')">Register Manager</button>
      <button class="navbtn" onclick="nav('login')">กลับไป Login</button>
    </div>

    <div id="staffBox">
      <div class="title">ลงทะเบียนพนักงาน</div>
      <div class="row">
        <div><label>ชื่อ - สกุล</label><input id="sf_full" oninput="previewUser('staff')"/></div>
        <div style="display:grid; grid-template-columns: 1fr 1fr; gap:10px">
          <div><label>ชื่อเล่น</label><input id="sf_nick"/></div>
          <div><label>เบอร์โทร</label><input id="sf_phone"/></div>
        </div>
        <div><label>Email</label><input id="sf_email" type="email" autocomplete="email"/></div>
        <div><label>Password</label><input id="sf_pass" type="password"/></div>
        <div class="small">Username: <b id="sf_user">-</b></div>
      </div>
      <div class="actions"><button class="btn btnPrimary" onclick="regStaff()">ลงทะเบียน</button></div>
      <div id="sf_st" class="status"></div>
    </div>

    <div id="mgrBox" style="display:none">
      <div class="title">ลงทะเบียนผู้จัดการ</div>
      <div class="row">
        <div><label>ชื่อ - สกุล</label><input id="mg_full" oninput="previewUser('manager')"/></div>
        <div style="display:grid; grid-template-columns: 1fr 1fr; gap:10px">
          <div><label>ชื่อเล่น</label><input id="mg_nick"/></div>
          <div><label>เบอร์โทร</label><input id="mg_phone"/></div>
        </div>
        <div><label>Email</label><input id="mg_email" type="email" autocomplete="email"/></div>
        <div><label>Password</label><input id="mg_pass" type="password"/></div>
        <div><label>รหัสยืนยันผู้จัดการ</label><input id="mg_code" type="password"/></div>
        <div class="small">Username: <b id="mg_user">-</b></div>
      </div>
      <div class="actions"><button class="btn btnPrimary" onclick="regManager()">ลงทะเบียน</button></div>
      <div id="mg_st" class="status"></div>
    </div>

    <div class="footer"><div>Branch: ${escHtml(BRANCH_NAME)}</div><div>Created by ${escHtml(CREATOR_CREDIT)}</div></div>
  </div></div>
</div>`;
  const script = `
function nav(page){ location.href = location.pathname + "?page=" + encodeURIComponent(page); }
function setStatus(id, msg, ok){ const el=document.getElementById(id); el.className="status "+(ok?"ok":"bad"); el.textContent=msg||""; }
async function api(path, payload){ const res=await fetch("/api/"+path,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(payload||{})}); return res.json(); }
function show(which){
  document.getElementById("btnStaff").classList.remove("active");
  document.getElementById("btnMgr").classList.remove("active");
  if(which==="staff"){ document.getElementById("btnStaff").classList.add("active"); document.getElementById("staffBox").style.display="block"; document.getElementById("mgrBox").style.display="none"; }
  else { document.getElementById("btnMgr").classList.add("active"); document.getElementById("staffBox").style.display="none"; document.getElementById("mgrBox").style.display="block"; }
}
function guessUser(fullName){
  if(!fullName) return "";
  const s=String(fullName).trim().replace(/\\s+/g," "); const parts=s.split(" ");
  if(parts.length<2) return "";
  const first=parts[0].slice(0,3); const last=parts[parts.length-1].slice(0,3);
  if(!first||!last) return "";
  return (first+last).toLowerCase()+"001";
}
function previewUser(kind){
  if(kind==="staff") document.getElementById("sf_user").textContent = guessUser(document.getElementById("sf_full").value) || "-";
  else document.getElementById("mg_user").textContent = guessUser(document.getElementById("mg_full").value) || "-";
}
async function regStaff(){
  setStatus("sf_st","กำลังลงทะเบียน...", true);
  const r=await api("registerStaff",{ fullName:sf_full.value, nickName:sf_nick.value, phone:sf_phone.value, email:sf_email.value, password:sf_pass.value });
  if(!r.ok){ setStatus("sf_st", r.message||"ไม่สำเร็จ", false); return; }
  setStatus("sf_st", "สำเร็จ • username: "+r.username, true);
}
async function regManager(){
  setStatus("mg_st","กำลังลงทะเบียน...", true);
  const r=await api("registerManager",{ fullName:mg_full.value, nickName:mg_nick.value, phone:mg_phone.value, email:mg_email.value, password:mg_pass.value, verifyCode:mg_code.value });
  if(!r.ok){ setStatus("mg_st", r.message||"ไม่สำเร็จ", false); return; }
  setStatus("mg_st", "สำเร็จ • username: "+r.username, true);
}`;
  return baseHtml("Register", body, script);
}

function htmlWork(){
  const body = `
<div class="wrap">
  <div class="header">
    <div class="brand"><div class="logo"></div><div>
      <div class="h1">BK ตารางงาน • ${escHtml(BRANCH_NAME)}</div><div class="h2">ตารางงานของฉัน</div></div></div>
    <div style="display:flex; gap:10px; align-items:center">
      <div id="uinfo" class="pill">...</div>
      <button class="btn btnGhost" onclick="doLogout()" style="padding:8px 12px">ออก</button>
    </div>
  </div>

  <div class="navbar">
    <button class="navbtn active" onclick="nav('work')">Work</button>
    <button class="navbtn" onclick="nav('roster')">Roster</button>
    <button id="btnSet" class="navbtn" style="display:none" onclick="nav('settings')">Settings</button>
  </div>

  <div class="card"><div class="inner">
    <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:14px">
      <div class="title">My Schedule</div>
      <div style="display:flex; gap:8px">
        <button class="btn btnGhost" onclick="addWeek(-1)">&lt;</button>
        <input type="date" id="picker" onchange="loadWeek(this.value)" style="width:auto; padding:8px; border:none; font-family:inherit; color:var(--primary); font-weight:900"/>
        <button class="btn btnGhost" onclick="addWeek(1)">&gt;</button>
      </div>
    </div>
    <div id="loading" class="muted">Loading...</div>
    <div id="content" style="display:none"></div>
    <div class="footer"><div>Branch: ${escHtml(BRANCH_NAME)}</div></div>
  </div></div>
</div>

<template id="tmpl-day">
  <div style="border:1px solid var(--line); border-radius:12px; padding:12px; margin-bottom:12px">
    <div style="display:flex; justify-content:space-between; margin-bottom:10px">
      <div class="d-date" style="font-weight:900; color:var(--muted)"></div>
      <div class="d-status"></div>
    </div>
    <div class="d-actions" style="display:grid; grid-template-columns:repeat(auto-fill, minmax(110px, 1fr)); gap:8px"></div>
  </div>
</template>`;
  const script = `
let DATA=null; let CURR_DATE=new Date().toISOString().split("T")[0];
function nav(page){ location.href = location.pathname + "?page=" + encodeURIComponent(page); }
async function api(path, payload){ const res=await fetch("/api/"+path,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(payload||{})}); return res.json(); }
function init(){ const t=localStorage.getItem("BK_TOKEN"); if(!t) return nav("login"); loadWeek(CURR_DATE); }
async function loadWeek(date){
  CURR_DATE = date || new Date().toISOString().split("T")[0];
  picker.value = CURR_DATE;
  loading.style.display="block"; content.style.display="none";
  const r=await api("getMyWeek",{ token: localStorage.getItem("BK_TOKEN"), anyDate: CURR_DATE });
  if(!r.ok){ alert(r.message||"ผิดพลาด"); if(String(r.message||"").includes("session")) nav("login"); return; }
  DATA=r; render();
}
function addWeek(n){ const d=new Date(CURR_DATE); d.setDate(d.getDate()+n*7); loadWeek(d.toISOString().split("T")[0]); }
function render(){
  loading.style.display="none"; content.style.display="block"; content.innerHTML="";
  uinfo.textContent = DATA.user.fullName;
  if(DATA.user.role==="admin"||DATA.user.role==="manager") btnSet.style.display="inline-block";

  const tmpl=tmpl-day;
  const days=["Sun","Mon","Tue","Wed","Thu","Fri","Sat"];
  DATA.days.forEach(day=>{
    const el=document.getElementById("tmpl-day").content.cloneNode(true);
    const dObj=new Date(day);
    el.querySelector(".d-date").textContent = day + " (" + days[dObj.getDay()] + ")";
    const my=DATA.items.find(x=>x.date===day);
    const act=el.querySelector(".d-actions");
    if(my){
      el.querySelector(".d-status").innerHTML = '<span class="chip">'+my.shiftGroup+' '+my.startTime+'-'+my.endTime+'</span>';
      const b=document.createElement("button"); b.className="btn btnDanger"; b.textContent="ยกเลิก";
      b.onclick=()=>doCancel(day); if(DATA.closed) b.disabled=true; act.appendChild(b);
    } else {
      if(DATA.closed) el.querySelector(".d-status").innerHTML="<span style='color:var(--danger)'>ปิดระบบ</span>";
      else DATA.groups.forEach(g=>{ const b=document.createElement("button"); b.className="btn btnGhost"; b.style.fontSize="12px"; b.textContent=g.label; b.onclick=()=>doBook(day,g.key,g.main); act.appendChild(b); });
    }
    content.appendChild(el);
  });
}
async function doBook(date, group, time){
  if(!confirm("ยืนยันลงกะ "+group+" วันที่ "+date+"?")) return;
  const r=await api("bookMyShift",{ token: localStorage.getItem("BK_TOKEN"), date, shiftGroup: group, startTime: time, note:"" });
  if(!r.ok) alert(r.message||"ไม่สำเร็จ"); else loadWeek(CURR_DATE);
}
async function doCancel(date){
  if(!confirm("ยืนยันยกเลิกกะวันที่ "+date+"?")) return;
  const r=await api("cancelMyShift",{ token: localStorage.getItem("BK_TOKEN"), date });
  if(!r.ok) alert(r.message||"ไม่สำเร็จ"); else loadWeek(CURR_DATE);
}
async function doLogout(){
  await api("logout",{ token: localStorage.getItem("BK_TOKEN") });
  localStorage.removeItem("BK_TOKEN");
  nav("login");
}
init();`;
  return baseHtml("Work", body, script);
}

function htmlRoster(){
  const body = `
<div class="wrap">
  <div class="header">
    <div class="brand"><div class="logo"></div><div>
      <div class="h1">BK ตารางงาน • ${escHtml(BRANCH_NAME)}</div><div class="h2">ตารางรวม</div></div></div>
    <div style="display:flex; gap:10px; align-items:center">
      <div id="uinfo" class="pill">...</div>
      <button class="btn btnGhost" onclick="doLogout()" style="padding:8px 12px">ออก</button>
    </div>
  </div>

  <div class="navbar">
    <button class="navbtn" onclick="nav('work')">Work</button>
    <button class="navbtn active" onclick="nav('roster')">Roster</button>
    <button id="btnSet" class="navbtn" style="display:none" onclick="nav('settings')">Settings</button>
  </div>

  <div class="card"><div class="inner">
    <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:14px">
      <div class="title">Team Roster</div>
      <div style="display:flex; gap:8px">
        <button class="btn btnGhost" onclick="addWeek(-1)">&lt;</button>
        <input type="date" id="picker" onchange="loadWeek(this.value)" style="width:auto; padding:8px; border:none; font-family:inherit; color:var(--primary); font-weight:900"/>
        <button class="btn btnGhost" onclick="addWeek(1)">&gt;</button>
      </div>
    </div>

    <div id="loading" class="muted">Loading...</div>
    <div style="overflow-x:auto">
      <table id="tbl" style="min-width:600px; display:none">
        <thead><tr id="thead-row"><th class="nameCol">Name</th></tr></thead>
        <tbody id="tbody"></tbody>
      </table>
    </div>

    <div class="footer"><div>Branch: ${escHtml(BRANCH_NAME)}</div></div>
  </div></div>
</div>

<div id="modal" class="modalBack">
  <div class="modal">
    <div class="hd">จัดการกะ</div>
    <div class="bd">
      <div class="row">
        <div><label>พนักงาน</label><input id="m_user" disabled/></div>
        <div><label>วันที่</label><input id="m_date" disabled/></div>
        <div><label>กะงาน</label><select id="m_group"></select></div>
        <div><label>เวลาเริ่ม</label><input id="m_time" type="time"/></div>
        <div><label>Note</label><input id="m_note"/></div>
      </div>
    </div>
    <div class="ft">
      <button class="btn btnDanger" onclick="doDeleteShift()">ลบกะ</button>
      <button class="btn btnGhost" onclick="closeModal()">ยกเลิก</button>
      <button class="btn btnPrimary" onclick="doSaveShift()">บันทึก</button>
    </div>
  </div>
</div>`;
  const script = `
let DATA=null; let CURR_DATE=new Date().toISOString().split("T")[0]; let SELECTED=null;
function nav(page){ location.href = location.pathname + "?page=" + encodeURIComponent(page); }
async function api(path, payload){ const res=await fetch("/api/"+path,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(payload||{})}); return res.json(); }
function init(){ const t=localStorage.getItem("BK_TOKEN"); if(!t) return nav("login"); loadWeek(CURR_DATE); }
async function loadWeek(date){
  CURR_DATE = date || new Date().toISOString().split("T")[0];
  picker.value = CURR_DATE; loading.style.display="block"; tbl.style.display="none";
  const r=await api("getRosterWeek",{ token: localStorage.getItem("BK_TOKEN"), anyDate: CURR_DATE });
  if(!r.ok){ alert(r.message||"ผิดพลาด"); if(String(r.message||"").includes("session")) nav("login"); return; }
  DATA=r; render();
}
function addWeek(n){ const d=new Date(CURR_DATE); d.setDate(d.getDate()+n*7); loadWeek(d.toISOString().split("T")[0]); }
function render(){
  loading.style.display="none"; tbl.style.display="table";
  uinfo.textContent = DATA.me.fullName;
  if(DATA.me.role==="admin"||DATA.me.role==="manager") btnSet.style.display="inline-block";

  const hr=document.getElementById("thead-row"); while(hr.children.length>1) hr.removeChild(hr.lastChild);
  const days=["Sun","Mon","Tue","Wed","Thu","Fri","Sat"];
  DATA.days.forEach(d=>{ const th=document.createElement("th"); const dd=new Date(d); th.innerHTML=d.split("-").slice(1).join("/")+"<br/>"+days[dd.getDay()]; hr.appendChild(th); });

  const tb=document.getElementById("tbody"); tb.innerHTML="";
  DATA.users.forEach(u=>{
    const tr=document.createElement("tr");
    const tdName=document.createElement("td");
    tdName.innerHTML = "<b>"+u.fullName+"</b><br/><span class='small'>"+(u.nickName||"")+"</span>";
    tr.appendChild(tdName);
    DATA.days.forEach(d=>{
      const td=document.createElement("td");
      const k=u.username.toLowerCase()+"|"+d;
      const s=DATA.map[k];
      td.innerHTML = s ? "<div class='chip'>"+s.shiftGroup+" "+s.startTime+"</div>" : "-";
      if(DATA.canManage){ td.style.cursor="pointer"; td.onclick=()=>openModal(u,d,s); }
      tr.appendChild(td);
    });
    tb.appendChild(tr);
  });
}
function openModal(user, date, shift){
  if(DATA.closed){ alert("ระบบปิดอยู่"); return; }
  SELECTED={ username:user.username, fullName:user.fullName, date, shift };
  m_user.value=user.fullName; m_date.value=date; m_note.value=shift?(shift.note||""):"";
  m_group.innerHTML="";
  DATA.groups.forEach(g=>{ const o=document.createElement("option"); o.value=g.key; o.textContent=g.label; if(shift&&shift.shiftGroup===g.key) o.selected=true; m_group.appendChild(o); });
  m_group.onchange=()=>{ const g=DATA.groups.find(x=>x.key===m_group.value); if(g) m_time.value=g.main; };
  m_time.value = shift ? shift.startTime : (DATA.groups[0]?.main || "00:00");
  modal.style.display="flex";
}
function closeModal(){ modal.style.display="none"; SELECTED=null; }
async function doSaveShift(){
  if(!SELECTED) return;
  const r=await api("setShiftForUser",{ token: localStorage.getItem("BK_TOKEN"), username: SELECTED.username, date: SELECTED.date, shiftGroup: m_group.value, startTime: m_time.value, note: m_note.value });
  if(!r.ok) alert(r.message||"ไม่สำเร็จ"); else { closeModal(); loadWeek(CURR_DATE); }
}
async function doDeleteShift(){
  if(!SELECTED) return;
  if(!confirm("ลบกะนี้?")) return;
  const r=await api("deleteShiftForUser",{ token: localStorage.getItem("BK_TOKEN"), username: SELECTED.username, date: SELECTED.date });
  if(!r.ok) alert(r.message||"ไม่สำเร็จ"); else { closeModal(); loadWeek(CURR_DATE); }
}
async function doLogout(){
  await api("logout",{ token: localStorage.getItem("BK_TOKEN") });
  localStorage.removeItem("BK_TOKEN"); nav("login");
}
init();`;
  return baseHtml("Roster", body, script);
}

function htmlSettings(){
  const body = `
<div class="wrap wrapNarrow">
  <div class="header">
    <div class="brand"><div class="logo"></div><div>
      <div class="h1">BK ตารางงาน • ${escHtml(BRANCH_NAME)}</div><div class="h2">ตั้งค่าระบบ</div></div></div>
    <button class="btn btnGhost" onclick="nav('work')" style="padding:8px 12px">กลับ</button>
  </div>

  <div class="card"><div class="inner">
    <div class="title">Capacity Settings</div>
    <div class="muted" style="margin-bottom:14px">กำหนดจำนวนคนที่รับในแต่ละกะ</div>

    <div id="loading" class="muted">Loading...</div>
    <div id="form" style="display:none">
      <div id="rows"></div>
      <div class="actions"><button class="btn btnPrimary" onclick="doSave()">บันทึก</button></div>
    </div>

    <div class="footer"><div>Branch: ${escHtml(BRANCH_NAME)}</div></div>
  </div></div>
</div>`;
  const script = `
let DATA=null;
function nav(page){ location.href = location.pathname + "?page=" + encodeURIComponent(page); }
async function api(path, payload){ const res=await fetch("/api/"+path,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(payload||{})}); return res.json(); }
(async function init(){
  const t=localStorage.getItem("BK_TOKEN"); if(!t) return nav("login");
  const r=await api("getSettings",{ token:t }); if(!r.ok){ alert(r.message||"สิทธิ์ไม่พอ"); return nav("work"); }
  DATA=r; render();
})();
function render(){
  loading.style.display="none"; form.style.display="block";
  rows.innerHTML="";
  DATA.groups.forEach(g=>{
    const div=document.createElement("div"); div.style.marginBottom="12px";
    const lbl=document.createElement("label"); lbl.textContent=g.label+" (Start "+g.windowStart+" - "+g.windowEnd+")";
    const inp=document.createElement("input"); inp.type="number"; inp.id="cap_"+g.key; inp.value=DATA.capacity[g.key]||0;
    div.appendChild(lbl); div.appendChild(inp); rows.appendChild(div);
  });
}
async function doSave(){
  const payload={}; DATA.groups.forEach(g=>{ payload[g.key]=document.getElementById("cap_"+g.key).value; });
  const r=await api("updateSettings",{ token: localStorage.getItem("BK_TOKEN"), capacity: payload });
  if(!r.ok) alert(r.message||"ไม่สำเร็จ"); else { alert("Saved"); nav("work"); }
}`;
  return baseHtml("Settings", body, script);
}

module.exports = {
  ping, setup,
  login, validate, logout,
  registerStaff, registerManager,
  getSettings, updateSettings,
  getMyWeek, bookMyShift, cancelMyShift,
  getRosterWeek, setShiftForUser, deleteShiftForUser,
  htmlLogin, htmlRegister, htmlWork, htmlRoster, htmlSettings
};
