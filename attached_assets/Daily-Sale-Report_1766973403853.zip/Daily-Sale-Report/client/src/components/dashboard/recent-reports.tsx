import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { ArrowRight } from "lucide-react";
import { useQuery } from "@tanstack/react-query";
import { format } from "date-fns";
import { th, enUS } from "date-fns/locale";
import { useLanguage } from "@/contexts/language-context";

export default function RecentReports() {
  const { t, language } = useLanguage();
  const dateLocale = language === 'th' ? th : enUS;

  const { data: recentReports, isLoading } = useQuery({
    queryKey: ["/api/daily-sales"],
    queryFn: async () => {
      const response = await fetch("/api/daily-sales?limit=5");
      if (!response.ok) {
        throw new Error("Failed to fetch reports");
      }
      return response.json();
    }
  });

  const getStatusLabel = (achievement: number) => {
    if (achievement >= 100) {
      return language === 'th' ? 'เกินเป้า' : 'Above Target';
    } else if (achievement >= 90) {
      return language === 'th' ? 'ใกล้เป้า' : 'Near Target';
    } else {
      return language === 'th' ? 'ต่ำกว่าเป้า' : 'Below Target';
    }
  };

  if (isLoading) {
    return (
      <Card className="border-gray-200">
        <CardHeader>
          <CardTitle className="text-lg font-semibold text-gray-900">
            {t.recentReports.title}
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="animate-pulse">
            <div className="space-y-3">
              {[1,2,3].map(i => (
                <div key={i} className="h-12 bg-gray-200 rounded"></div>
              ))}
            </div>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="border-gray-200">
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle className="text-lg font-semibold text-gray-900">
            {t.recentReports.title}
          </CardTitle>
          <Button 
            variant="ghost" 
            className="text-bk-red hover:text-red-700 text-sm font-medium"
            onClick={() => window.location.href = '/reports'}
            data-testid="button-view-all"
          >
            {language === 'th' ? 'ดูทั้งหมด' : 'View All'} <ArrowRight className="w-4 h-4 ml-1" />
          </Button>
        </div>
      </CardHeader>
      <CardContent>
        {!recentReports || recentReports.length === 0 ? (
          <div className="text-center py-8 text-gray-500">
            <p>{t.recentReports.noReports}</p>
            <p className="text-sm mt-1">
              <a href="/daily-sales" className="text-bk-red hover:text-red-700">
                {t.recentReports.recordFirst}
              </a>
            </p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="text-left text-xs text-gray-500 uppercase tracking-wider">
                  <th className="pb-3">{t.recentReports.date}</th>
                  <th className="pb-3">{t.recentReports.sales}</th>
                  <th className="pb-3">{t.recentReports.target}</th>
                  <th className="pb-3">{t.recentReports.transactions}</th>
                  <th className="pb-3">{t.recentReports.status}</th>
                </tr>
              </thead>
              <tbody className="text-sm">
                {recentReports.map((report: any) => {
                  const actual = parseFloat(report.actualSales);
                  const target = parseFloat(report.dailyTarget);
                  const achievement = target > 0 ? (actual / target) * 100 : 0;
                  
                  return (
                    <tr key={report.id} className="border-t border-gray-100 hover:bg-gray-50 cursor-pointer">
                      <td className="py-3">
                        {format(new Date(report.reportDate), "d MMM yyyy", { locale: dateLocale })}
                      </td>
                      <td className="py-3 font-medium">
                        ₿{actual.toLocaleString()}
                      </td>
                      <td className="py-3 text-gray-500">
                        ₿{target.toLocaleString()}
                      </td>
                      <td className="py-3">{report.transactionCount.toLocaleString()}</td>
                      <td className="py-3">
                        <Badge 
                          variant="secondary" 
                          className={
                            achievement >= 100 
                              ? "bg-green-100 text-green-800"
                              : achievement >= 90
                                ? "bg-yellow-100 text-yellow-800"
                                : "bg-red-100 text-red-800"
                          }
                        >
                          {getStatusLabel(achievement)}
                        </Badge>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
