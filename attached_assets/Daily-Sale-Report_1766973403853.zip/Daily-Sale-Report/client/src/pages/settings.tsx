import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { useLanguage } from "@/contexts/language-context";

export default function Settings() {
  const { t, language, setLanguage } = useLanguage();
  
  return (
    <div className="space-y-6">
      <Card className="border-gray-200">
        <CardHeader>
          <CardTitle className="text-lg font-semibold text-gray-900">
            {t.pages.settings.storeSettings}
          </CardTitle>
          <p className="text-gray-600 text-sm">{t.pages.settings.storeSettingsDesc}</p>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <Label htmlFor="storeName">{t.pages.settings.storeName}</Label>
              <Input 
                id="storeName"
                defaultValue="BK Grand Diamond Plaza" 
                className="mt-2"
                data-testid="input-store-name"
              />
            </div>
            <div>
              <Label htmlFor="storeCode">{t.pages.settings.storeCode}</Label>
              <Input 
                id="storeCode"
                defaultValue="BK001GDP" 
                className="mt-2"
                data-testid="input-store-code"
              />
            </div>
            <div className="md:col-span-2">
              <Label htmlFor="dailyTarget">{t.pages.settings.dailyTarget}</Label>
              <div className="relative mt-2">
                <span className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-500">₿</span>
                <Input 
                  id="dailyTarget"
                  type="number"
                  defaultValue="250000" 
                  className="pl-8"
                  data-testid="input-daily-target"
                />
              </div>
            </div>
          </div>
          <div className="mt-6 flex justify-end">
            <Button className="bg-bk-red hover:bg-red-700" data-testid="button-save-store">
              {t.pages.settings.saveChanges}
            </Button>
          </div>
        </CardContent>
      </Card>

      <Card className="border-gray-200">
        <CardHeader>
          <CardTitle className="text-lg font-semibold text-gray-900">
            {t.pages.settings.userPreferences}
          </CardTitle>
          <p className="text-gray-600 text-sm">{t.pages.settings.userPreferencesDesc}</p>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <Label>{t.pages.settings.language}</Label>
              <Select value={language} onValueChange={(val) => setLanguage(val as 'th' | 'en')}>
                <SelectTrigger className="mt-2" data-testid="select-language">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="th">🇹🇭 ไทย</SelectItem>
                  <SelectItem value="en">🇺🇸 English</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label>{language === 'th' ? 'โซนเวลา' : 'Time Zone'}</Label>
              <Select defaultValue="asia-bangkok">
                <SelectTrigger className="mt-2">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="asia-bangkok">Asia/Bangkok (GMT+7)</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          <div className="mt-4">
            <div className="flex items-center space-x-2">
              <Checkbox id="notifications" defaultChecked data-testid="checkbox-notifications" />
              <Label htmlFor="notifications" className="text-sm text-gray-700">
                {t.pages.settings.enableNotifications}
              </Label>
            </div>
          </div>
          <div className="mt-6 flex justify-end">
            <Button className="bg-bk-red hover:bg-red-700" data-testid="button-save-preferences">
              {t.pages.settings.saveChanges}
            </Button>
          </div>
        </CardContent>
      </Card>

      <Card className="border-gray-200">
        <CardHeader>
          <CardTitle className="text-lg font-semibold text-gray-900">
            {language === 'th' ? 'ข้อมูลระบบ' : 'System Information'}
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            <div className="flex justify-between">
              <span className="text-sm text-gray-600">{language === 'th' ? 'เวอร์ชัน:' : 'Version:'}</span>
              <span className="text-sm font-medium">1.0.0</span>
            </div>
            <div className="flex justify-between">
              <span className="text-sm text-gray-600">{language === 'th' ? 'ปรับปรุงล่าสุด:' : 'Last Updated:'}</span>
              <span className="text-sm font-medium">{new Date().toLocaleDateString(language === 'th' ? 'th-TH' : 'en-US')}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-sm text-gray-600">{language === 'th' ? 'ผู้พัฒนา:' : 'Developer:'}</span>
              <span className="text-sm font-medium">Chanon Jaimool</span>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
