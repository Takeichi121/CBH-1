import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { LanguageProvider, useLanguage } from "@/contexts/language-context";
import Dashboard from "@/pages/dashboard";
import DailySales from "@/pages/daily-sales";
import Settings from "@/pages/settings";
import Reports from "@/pages/reports";
import Staff from "@/pages/staff";
import NotFound from "@/pages/not-found";
import Sidebar from "@/components/layout/sidebar";
import Header from "@/components/layout/header";
import { useState } from "react";

function Router() {
  return (
    <Switch>
      <Route path="/" component={Dashboard} />
      <Route path="/dashboard" component={Dashboard} />
      <Route path="/daily-sales" component={DailySales} />
      <Route path="/reports" component={Reports} />
      <Route path="/staff" component={Staff} />
      <Route path="/settings" component={Settings} />
      <Route component={NotFound} />
    </Switch>
  );
}

function AppContent() {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const { language } = useLanguage();

  return (
    <div className="min-h-screen bg-gray-50">
      <Sidebar isOpen={sidebarOpen} onToggle={setSidebarOpen} />
      
      <div className="lg:ml-64">
        <Header onMenuToggle={() => setSidebarOpen(!sidebarOpen)} />
        
        <main className="p-6">
          <Router />
        </main>
        
        <footer className="bg-white border-t border-gray-200 px-6 py-4">
          <div className="flex items-center justify-between text-sm text-gray-500">
            <div>
              <span>© 2025 BK Grand Diamond Plaza. Developed by Chanon Jaimool</span>
            </div>
            <div className="flex items-center space-x-4">
              <span>{language === 'th' ? 'เวอร์ชัน' : 'Version'} 1.0.0</span>
              <span>|</span>
              <span>
                {language === 'th' ? 'ปรับปรุงล่าสุด:' : 'Last updated:'}{' '}
                {new Date().toLocaleDateString(language === 'th' ? 'th-TH' : 'en-US')}
              </span>
            </div>
          </div>
        </footer>
      </div>
    </div>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <LanguageProvider>
          <AppContent />
          <Toaster />
        </LanguageProvider>
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
