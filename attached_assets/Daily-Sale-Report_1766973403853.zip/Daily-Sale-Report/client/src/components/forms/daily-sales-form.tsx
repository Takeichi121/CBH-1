import { useState, useEffect } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { CheckCircle, Save, Trash2, Check, Copy } from "lucide-react";
import { useFormPersistence } from "@/hooks/use-form-persistence";
import { useUnsavedChanges } from "@/hooks/use-unsaved-changes";
import { useToast } from "@/hooks/use-toast";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useLanguage } from "@/contexts/language-context";

const formSchema = z.object({
  reportDate: z.string().min(1, "กรุณาเลือกวันที่"),
  reportBy: z.string().min(1, "กรุณากรอกชื่อผู้รายงาน"),
  workShift: z.string().min(1, "กรุณาเลือกกะการทำงาน"),
  dailyTarget: z.string().min(1, "กรุณากรอกเป้าหมายรายวัน"),
  actualSales: z.string().min(1, "กรุณากรอกยอดขายจริง"),
  transactionCount: z.string().min(1, "กรุณากรอกจำนวนธุรกรรม"),
  dineIn: z.string().default("0"),
  takeAway: z.string().default("0"),
  delivery: z.string().default("0"),
  grabfood: z.string().default("0"),
  lineman: z.string().default("0"),
  shopee: z.string().default("0"),
  foodpanda: z.string().default("0"),
  gokoo: z.string().default("0"),
  bkapp: z.string().default("0"),
  sos: z.string().default("0"),
  mtdSos: z.string().default("0"),
  voidCount: z.string().default("0"),
  tcmh: z.string().default("0"),
  colAc: z.string().default("0"),
  gsi: z.string().default("0"),
  osat: z.string().default("0"),
  googleReview: z.string().default("0"),
  deliveryRating: z.string().default("0"),
  wasteDaily: z.string().default("0"),
  mealDaily: z.string().default("0"),
  addCheese: z.string().default("0"),
  vMeal: z.string().default("0"),
  upSize: z.string().default("0"),
  mtdTarget: z.string().default("0"),
  mtdActual: z.string().default("0"),
  mtdTc: z.string().default("0"),
  rosterPhongsathorn: z.string().default(""),
  rosterNuttarika: z.string().default(""),
  rosterChanon: z.string().default(""),
  rosterWachiraphat: z.string().default(""),
});

type FormData = z.infer<typeof formSchema>;

export default function DailySalesForm() {
  const { toast } = useToast();
  const { t, language } = useLanguage();
  const [lastSaved, setLastSaved] = useState<Date | null>(null);
  const [showAutoSave, setShowAutoSave] = useState(false);

  const form = useForm<FormData>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      reportDate: new Date().toISOString().split('T')[0],
      reportBy: "",
      workShift: "",
      dailyTarget: "",
      actualSales: "",
      transactionCount: "",
      dineIn: "0",
      takeAway: "0",
      delivery: "0",
      grabfood: "0",
      lineman: "0",
      shopee: "0",
      foodpanda: "0",
      gokoo: "0",
      bkapp: "0",
      sos: "0",
      mtdSos: "0",
      voidCount: "0",
      tcmh: "0",
      colAc: "0",
      gsi: "0",
      osat: "0",
      googleReview: "0",
      deliveryRating: "0",
      wasteDaily: "0",
      mealDaily: "0",
      addCheese: "0",
      vMeal: "0",
      upSize: "0",
      mtdTarget: "0",
      mtdActual: "0",
      mtdTc: "0",
      rosterPhongsathorn: "",
      rosterNuttarika: "",
      rosterChanon: "",
      rosterWachiraphat: "",
    }
  });

  const { 
    saveData, 
    restoreData, 
    clearData, 
    hasDraft,
    lastAutoSave 
  } = useFormPersistence<FormData>('daily-sales-form');

  const { hasUnsavedChanges, markAsSaved } = useUnsavedChanges();

  // Auto-save functionality
  useEffect(() => {
    const subscription = form.watch((values) => {
      if (Object.values(values).some(value => value && value !== "0")) {
        const timer = setTimeout(() => {
          saveData(values as FormData);
          setLastSaved(new Date());
          setShowAutoSave(true);
          setTimeout(() => setShowAutoSave(false), 3000);
        }, 1000);

        return () => clearTimeout(timer);
      }
    });

    return () => subscription.unsubscribe();
  }, [form.watch, saveData]);

  // Restore data on component mount
  useEffect(() => {
    const restored = restoreData();
    if (restored) {
      (Object.keys(restored) as Array<keyof FormData>).forEach((key) => {
        if (restored[key] !== undefined) {
          form.setValue(key, restored[key]);
        }
      });
    }
  }, [form.setValue, restoreData]);

  // Calculate average transaction
  useEffect(() => {
    const subscription = form.watch((values) => {
      const actualSales = parseFloat(values.actualSales || "0");
      const transactionCount = parseInt(values.transactionCount || "0");
      
      if (actualSales > 0 && transactionCount > 0) {
        const avg = (actualSales / transactionCount).toFixed(2);
        // This would be displayed in a readonly field
      }
    });

    return () => subscription.unsubscribe();
  }, [form.watch]);

  const queryClient = useQueryClient();
  
  const mutation = useMutation({
    mutationFn: async (data: FormData) => {
      // Transform form data to match API schema
      const apiData = {
        reportDate: data.reportDate,
        reportBy: data.reportBy,
        workShift: data.workShift,
        dailyTarget: data.dailyTarget,
        actualSales: data.actualSales,
        transactionCount: parseInt(data.transactionCount) || 0,
        dineIn: data.dineIn,
        takeAway: data.takeAway,
        delivery: data.delivery,
        deliveryBreakdown: {
          grabfood: parseFloat(data.grabfood) || 0,
          lineman: parseFloat(data.lineman) || 0,
          shopee: parseFloat(data.shopee) || 0,
          foodpanda: parseFloat(data.foodpanda) || 0,
          gokoo: parseFloat(data.gokoo) || 0,
          bkapp: parseFloat(data.bkapp) || 0,
        },
        sos: parseInt(data.sos) || null,
        mtdSos: parseInt(data.mtdSos) || null,
        voidCount: parseInt(data.voidCount) || 0,
        tcmh: data.tcmh || null,
        colAc: parseInt(data.colAc) || null,
        gsi: data.gsi || null,
        osat: data.osat || null,
        googleReview: data.googleReview || null,
        deliveryRating: data.deliveryRating || null,
        wasteDaily: data.wasteDaily || '0',
        mealDaily: data.mealDaily || '0',
        addCheese: data.addCheese || '0',
        vMeal: data.vMeal || '0',
        upSize: data.upSize || '0',
        rosterStaff: {
          phongsathorn: data.rosterPhongsathorn || '',
          nuttarika: data.rosterNuttarika || '',
          chanon: data.rosterChanon || '',
          wachiraphat: data.rosterWachiraphat || '',
        },
      };
      
      return await apiRequest("POST", "/api/daily-sales", apiData);
    },
    onSuccess: () => {
      clearData();
      markAsSaved();
      form.reset({
        reportDate: new Date().toISOString().split('T')[0],
        reportBy: "",
        workShift: "",
        dailyTarget: "",
        actualSales: "",
        transactionCount: "",
        dineIn: "0",
        takeAway: "0",
        delivery: "0",
        grabfood: "0",
        lineman: "0",
        shopee: "0",
        foodpanda: "0",
        gokoo: "0",
        bkapp: "0",
        sos: "0",
        mtdSos: "0",
        voidCount: "0",
        tcmh: "0",
        colAc: "0",
        gsi: "0",
        osat: "0",
        googleReview: "0",
        deliveryRating: "0",
        wasteDaily: "0",
        mealDaily: "0",
        addCheese: "0",
        vMeal: "0",
        upSize: "0",
        mtdTarget: "0",
        mtdActual: "0",
        mtdTc: "0",
        rosterPhongsathorn: "",
        rosterNuttarika: "",
        rosterChanon: "",
        rosterWachiraphat: "",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/daily-sales"] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard/kpi"] });
      toast({
        title: t.form.saveSuccess,
        description: t.form.saveSuccessDesc,
      });
    },
    onError: (error: any) => {
      console.error("Submission error:", error);
      toast({
        title: t.form.error,
        description: error.message || t.form.errorDesc,
        variant: "destructive",
      });
    }
  });

  const onSubmit = (data: FormData) => {
    mutation.mutate(data);
  };

  const handleSaveDraft = () => {
    const currentValues = form.getValues();
    saveData(currentValues);
    toast({
      title: t.form.draftSaved,
      description: t.form.draftSavedDesc,
    });
  };

  const handleClearForm = () => {
    const confirmMessage = language === 'th' 
      ? 'คุณแน่ใจหรือไม่ที่จะล้างข้อมูลทั้งหมด?' 
      : 'Are you sure you want to clear all data?';
    if (confirm(confirmMessage)) {
      clearData();
      form.reset();
      markAsSaved();
    }
  };

  const handleCopyReport = () => {
    const values = form.getValues();
    const actualSalesVal = parseFloat(values.actualSales) || 0;
    const tcVal = parseInt(values.transactionCount) || 0;
    const taVal = tcVal > 0 ? (actualSalesVal / tcVal).toFixed(2) : "0";
    const mtdActualVal = parseFloat(values.mtdActual) || 0;
    const mtdTargetVal = parseFloat(values.mtdTarget) || 0;
    const mtdVariance = mtdActualVal - mtdTargetVal;
    const mtdTcVal = parseInt(values.mtdTc) || 0;
    const mtdTaVal = mtdTcVal > 0 ? (mtdActualVal / mtdTcVal).toFixed(2) : "0";
    const totalWaste = (parseFloat(values.wasteDaily) || 0) + (parseFloat(values.mealDaily) || 0);

    const reportText = `💎 BK Grand Diamond♦️
 Date : ${values.reportDate}
💵 TG = ${parseFloat(values.dailyTarget).toLocaleString()}
💵 AC = ${actualSalesVal.toLocaleString()}
👨‍👩‍👧‍👦 TC = ${tcVal.toLocaleString()}
🧾 TA = ${taVal}

💵 MTD TG = ${mtdTargetVal.toLocaleString()}
💵 MTD AC = ${mtdActualVal.toLocaleString()}
📈 Variance = ${mtdVariance >= 0 ? '+' : ''}${mtdVariance.toLocaleString()}
👨‍👩‍👧‍👦 MTD TC = ${mtdTcVal.toLocaleString()}
🧾 MTD TA = ${mtdTaVal}

Sales By Channel 
🍽 Dine In = ${parseFloat(values.dineIn).toLocaleString()}
🥡Take Away = ${parseFloat(values.takeAway).toLocaleString()}
🛵 Delivery = ${parseFloat(values.delivery).toLocaleString()}
🔻
🛵 Grabfood : ${parseFloat(values.grabfood).toLocaleString()}
🛵 Line man : ${parseFloat(values.lineman).toLocaleString()}
🛵 Shopee : ${parseFloat(values.shopee).toLocaleString()}
🛵 BK App : ${parseFloat(values.bkapp).toLocaleString()}

🔖 Void = ${values.voidCount}

🏆 GSI = ${values.gsi}
🏃🏻‍♀️SOS = ${values.sos}
🏃🏻MTD SOS = ${values.mtdSos}

🪣 Waste Daily = ${parseFloat(values.wasteDaily).toLocaleString()}
        Meal Daily = ${parseFloat(values.mealDaily).toLocaleString()}
All Waste Daily ‎ = ${totalWaste.toLocaleString()}

🧰 COL / AC = ${values.colAc} Hr.
📍TCMH = ${values.tcmh}

🧀 Add Cheese = ${parseFloat(values.addCheese).toLocaleString()}
🍟 V-meal = ${parseFloat(values.vMeal).toLocaleString()}
🍔 Up Size = ${parseFloat(values.upSize).toLocaleString()}

Report by ${values.reportBy}`;

    navigator.clipboard.writeText(reportText).then(() => {
      toast({
        title: language === 'th' ? "คัดลอกสำเร็จ" : "Copied Successfully",
        description: language === 'th' ? "รายงานถูกคัดลอกไปยังคลิปบอร์ดแล้ว" : "Report has been copied to clipboard",
      });
    }).catch(() => {
      toast({
        title: language === 'th' ? "เกิดข้อผิดพลาด" : "Error",
        description: language === 'th' ? "ไม่สามารถคัดลอกได้" : "Unable to copy",
        variant: "destructive",
      });
    });
  };

  const actualSales = parseFloat(form.watch("actualSales") || "0");
  const transactionCount = parseInt(form.watch("transactionCount") || "0");
  const avgTransaction = transactionCount > 0 ? (actualSales / transactionCount).toFixed(2) : "0";

  return (
    <Card className="border-gray-200">
      <CardHeader>
        <div className="flex items-center justify-between">
          <div>
            <CardTitle className="text-xl font-semibold text-gray-900" data-testid="text-form-title">
              {t.pages.dailySales.formTitle}
            </CardTitle>
            <p className="text-gray-600 text-sm mt-1">
              {t.pages.dailySales.formSubtitle}
            </p>
          </div>
          <div className="flex items-center space-x-3">
            {hasDraft && (
              <Badge variant="secondary" className="bg-amber-50 border-amber-200 text-amber-700">
                <div className="w-2 h-2 bg-amber-400 rounded-full animate-pulse mr-2" />
                {t.form.unsavedDraft}
              </Badge>
            )}
            {showAutoSave && (
              <div className="flex items-center space-x-2 text-xs text-gray-500">
                <CheckCircle className="w-4 h-4 text-green-500" />
                <span>{t.form.autoSaved}</span>
                <span>{lastSaved?.toLocaleTimeString(language === 'th' ? 'th-TH' : 'en-US')}</span>
              </div>
            )}
          </div>
        </div>
      </CardHeader>

      <CardContent>
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-8">
            {/* Basic Information */}
            <div>
              <h3 className="text-lg font-medium text-gray-900 mb-4">{t.form.basicInfo}</h3>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <FormField
                  control={form.control}
                  name="reportDate"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>{t.form.date}</FormLabel>
                      <FormControl>
                        <Input type="date" {...field} data-testid="input-report-date" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="reportBy"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>{t.form.reporter}</FormLabel>
                      <FormControl>
                        <Input placeholder={t.form.reporterPlaceholder} {...field} data-testid="input-reporter" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="workShift"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>{t.form.shift}</FormLabel>
                      <Select onValueChange={field.onChange} value={field.value}>
                        <FormControl>
                          <SelectTrigger data-testid="select-shift">
                            <SelectValue placeholder={t.form.selectShift} />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="morning">{t.form.morning}</SelectItem>
                          <SelectItem value="evening">{t.form.evening}</SelectItem>
                          <SelectItem value="full">{t.form.fullDay}</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
            </div>

            {/* Sales Data */}
            <div>
              <h3 className="text-lg font-medium text-gray-900 mb-4">{t.form.salesData}</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                <FormField
                  control={form.control}
                  name="dailyTarget"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>{t.form.todayTarget}</FormLabel>
                      <FormControl>
                        <div className="relative">
                          <span className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-500">₿</span>
                          <Input type="number" placeholder="0.00" className="pl-8" {...field} data-testid="input-daily-target" />
                        </div>
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="actualSales"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>{t.form.actualSales}</FormLabel>
                      <FormControl>
                        <div className="relative">
                          <span className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-500">₿</span>
                          <Input type="number" placeholder="0.00" className="pl-8" {...field} data-testid="input-actual-sales" />
                        </div>
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="transactionCount"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>{t.form.transactionCount}</FormLabel>
                      <FormControl>
                        <Input type="number" placeholder="0" {...field} data-testid="input-transactions" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <div>
                  <FormLabel>{t.form.avgTransaction}</FormLabel>
                  <Input 
                    type="number" 
                    placeholder="0" 
                    value={avgTransaction}
                    readOnly
                    className="bg-gray-50"
                    data-testid="input-avg-transaction"
                  />
                </div>
              </div>
            </div>

            {/* Sales by Channel */}
            <div>
              <h3 className="text-lg font-medium text-gray-900 mb-4">{t.form.salesByChannel}</h3>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
                <FormField
                  control={form.control}
                  name="dineIn"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>{t.form.dineIn}</FormLabel>
                      <FormControl>
                        <div className="relative">
                          <span className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-500">₿</span>
                          <Input type="number" placeholder="0.00" className="pl-8" {...field} data-testid="input-dine-in" />
                        </div>
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="takeAway"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>{t.form.takeAway}</FormLabel>
                      <FormControl>
                        <div className="relative">
                          <span className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-500">₿</span>
                          <Input type="number" placeholder="0.00" className="pl-8" {...field} data-testid="input-take-away" />
                        </div>
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="delivery"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>{t.form.totalDelivery}</FormLabel>
                      <FormControl>
                        <div className="relative">
                          <span className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-500">₿</span>
                          <Input type="number" placeholder="0.00" className="pl-8" {...field} data-testid="input-delivery" />
                        </div>
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              {/* Delivery Breakdown */}
              <div>
                <h4 className="text-sm font-medium text-gray-700 mb-3">{t.form.deliveryBreakdown}</h4>
                <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3">
                  {[
                    { name: "grabfood", label: "GrabFood" },
                    { name: "lineman", label: "LINE MAN" },
                    { name: "shopee", label: "Shopee Food" },
                    { name: "foodpanda", label: "foodpanda" },
                    { name: "gokoo", label: "GoKoo" },
                    { name: "bkapp", label: "BK App" },
                  ].map((delivery) => (
                    <FormField
                      key={delivery.name}
                      control={form.control}
                      name={delivery.name as keyof FormData}
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel className="text-xs text-gray-600">{delivery.label}</FormLabel>
                          <FormControl>
                            <Input 
                              type="number" 
                              placeholder="0.00" 
                              className="text-sm"
                              {...field} 
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  ))}
                </div>
              </div>
            </div>

            {/* MTD Data */}
            <div>
              <h3 className="text-lg font-medium text-gray-900 mb-4">{language === 'th' ? 'ข้อมูล MTD' : 'MTD Data'}</h3>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                {[
                  { name: "mtdTarget", label: "MTD TG" },
                  { name: "mtdActual", label: "MTD AC" },
                  { name: "mtdTc", label: "MTD TC" },
                ].map((field) => (
                  <FormField
                    key={field.name}
                    control={form.control}
                    name={field.name as keyof FormData}
                    render={({ field: formField }) => (
                      <FormItem>
                        <FormLabel>{field.label}</FormLabel>
                        <FormControl>
                          <div className="relative">
                            <span className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-500">{field.name === 'mtdTc' ? '' : '₿'}</span>
                            <Input 
                              type="number" 
                              placeholder="0"
                              className={field.name === 'mtdTc' ? '' : 'pl-8'}
                              {...formField} 
                            />
                          </div>
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                ))}
              </div>
            </div>

            {/* Operational Metrics */}
            <div>
              <h3 className="text-lg font-medium text-gray-900 mb-4">{t.form.operationalMetrics}</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4">
                {[
                  { name: "sos", label: language === 'th' ? "SOS (วินาที)" : "SOS (seconds)", type: "number" },
                  { name: "mtdSos", label: language === 'th' ? "MTD SOS (วินาที)" : "MTD SOS (seconds)", type: "number" },
                  { name: "voidCount", label: language === 'th' ? "จำนวน Void" : "Void Count", type: "number" },
                  { name: "tcmh", label: "TCMH", type: "number", step: "0.01" },
                  { name: "colAc", label: language === 'th' ? "COL AC (ชั่วโมง)" : "COL AC (hours)", type: "number" },
                ].map((field) => (
                  <FormField
                    key={field.name}
                    control={form.control}
                    name={field.name as keyof FormData}
                    render={({ field: formField }) => (
                      <FormItem>
                        <FormLabel>{field.label}</FormLabel>
                        <FormControl>
                          <Input 
                            type={field.type}
                            step={field.step}
                            placeholder="0"
                            {...formField} 
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                ))}
              </div>
            </div>

            {/* Customer Satisfaction */}
            <div>
              <h3 className="text-lg font-medium text-gray-900 mb-4">{t.form.customerSatisfaction}</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                {[
                  { name: "gsi", label: "GSI" },
                  { name: "osat", label: "OSAT" },
                  { name: "googleReview", label: "Google Review" },
                  { name: "deliveryRating", label: "Delivery Rating" },
                ].map((field) => (
                  <FormField
                    key={field.name}
                    control={form.control}
                    name={field.name as keyof FormData}
                    render={({ field: formField }) => (
                      <FormItem>
                        <FormLabel>{field.label}</FormLabel>
                        <FormControl>
                          <Input 
                            type="number" 
                            step="0.01"
                            placeholder="0.00"
                            {...formField} 
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                ))}
              </div>
            </div>

            {/* Waste Data */}
            <div>
              <h3 className="text-lg font-medium text-gray-900 mb-4">{language === 'th' ? 'ข้อมูล Waste' : 'Waste Data'}</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <FormField
                  control={form.control}
                  name="wasteDaily"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Waste Daily</FormLabel>
                      <FormControl>
                        <div className="relative">
                          <span className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-500">₿</span>
                          <Input type="number" placeholder="0.00" className="pl-8" {...field} />
                        </div>
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="mealDaily"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Meal Daily</FormLabel>
                      <FormControl>
                        <div className="relative">
                          <span className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-500">₿</span>
                          <Input type="number" placeholder="0.00" className="pl-8" {...field} />
                        </div>
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
            </div>

            {/* Add-on Sales */}
            <div>
              <h3 className="text-lg font-medium text-gray-900 mb-4">{language === 'th' ? 'ยอดขาย Add-on' : 'Add-on Sales'}</h3>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <FormField
                  control={form.control}
                  name="addCheese"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>🧀 Add Cheese</FormLabel>
                      <FormControl>
                        <div className="relative">
                          <span className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-500">₿</span>
                          <Input type="number" placeholder="0.00" className="pl-8" {...field} />
                        </div>
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="vMeal"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>🍟 V-meal</FormLabel>
                      <FormControl>
                        <div className="relative">
                          <span className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-500">₿</span>
                          <Input type="number" placeholder="0.00" className="pl-8" {...field} />
                        </div>
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="upSize"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>🍔 Up Size</FormLabel>
                      <FormControl>
                        <div className="relative">
                          <span className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-500">₿</span>
                          <Input type="number" placeholder="0.00" className="pl-8" {...field} />
                        </div>
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
            </div>

            {/* Form Actions */}
            <div className="flex flex-wrap items-center justify-between pt-6 border-t border-gray-200 gap-4">
              <div className="flex items-center space-x-4">
                <Button 
                  type="button" 
                  variant="outline"
                  onClick={handleSaveDraft}
                  data-testid="button-save-draft"
                >
                  <Save className="w-4 h-4 mr-2" />
                  {t.form.saveDraft}
                </Button>
                <Button 
                  type="button" 
                  variant="outline"
                  onClick={handleCopyReport}
                  className="text-bk-red border-bk-red hover:bg-red-50"
                  data-testid="button-copy-report"
                >
                  <Copy className="w-4 h-4 mr-2" />
                  {language === 'th' ? 'คัดลอกรายงาน' : 'Copy Report'}
                </Button>
                <Button 
                  type="button" 
                  variant="ghost"
                  onClick={handleClearForm}
                  className="text-gray-500 hover:text-gray-700"
                  data-testid="button-clear"
                >
                  <Trash2 className="w-4 h-4 mr-2" />
                  {t.form.clearData}
                </Button>
              </div>
              <div className="flex items-center space-x-3">
                <Button type="button" variant="outline" data-testid="button-cancel">
                  {t.form.cancel}
                </Button>
                <Button 
                  type="submit" 
                  className="bg-bk-red hover:bg-red-700"
                  disabled={mutation.isPending}
                  data-testid="button-submit"
                >
                  <Check className="w-4 h-4 mr-2" />
                  {mutation.isPending ? t.form.saving : t.form.saveData}
                </Button>
              </div>
            </div>
          </form>
        </Form>
      </CardContent>
    </Card>
  );
}
