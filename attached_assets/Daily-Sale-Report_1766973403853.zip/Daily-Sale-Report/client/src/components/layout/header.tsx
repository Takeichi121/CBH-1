import { Menu, Bell, Globe } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useLocation } from "wouter";
import { useLanguage } from "@/contexts/language-context";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

interface HeaderProps {
  onMenuToggle: () => void;
}

export default function Header({ onMenuToggle }: HeaderProps) {
  const [location] = useLocation();
  const { language, setLanguage, t } = useLanguage();
  
  const getPageTitle = () => {
    switch (location) {
      case "/":
      case "/dashboard":
        return t.pages.dashboard.title;
      case "/daily-sales":
        return t.pages.dailySales.title;
      case "/settings":
        return t.pages.settings.title;
      case "/reports":
        return t.pages.reports.title;
      case "/staff":
        return t.pages.staff.title;
      default:
        return "BK Dashboard";
    }
  };

  const getPageSubtitle = () => {
    switch (location) {
      case "/":
      case "/dashboard":
        return t.pages.dashboard.subtitle;
      case "/daily-sales":
        return t.pages.dailySales.subtitle;
      case "/settings":
        return t.pages.settings.subtitle;
      case "/reports":
        return t.pages.reports.subtitle;
      case "/staff":
        return t.pages.staff.subtitle;
      default:
        return "";
    }
  };
  
  const currentDateTime = new Date().toLocaleDateString(language === 'th' ? 'th-TH' : 'en-US', {
    day: 'numeric',
    month: 'long', 
    year: 'numeric',
    hour: '2-digit',
    minute: '2-digit'
  });

  return (
    <header className="bg-white border-b border-gray-200 px-6 py-4">
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-4">
          <Button
            variant="ghost"
            size="sm" 
            className="lg:hidden"
            onClick={onMenuToggle}
            data-testid="button-menu-toggle"
          >
            <Menu className="w-5 h-5" />
          </Button>
          
          <div>
            <h1 className="text-2xl font-bold text-gray-900" data-testid="text-page-title">{getPageTitle()}</h1>
            {getPageSubtitle() && (
              <p className="text-gray-600 text-sm mt-1" data-testid="text-page-subtitle">{getPageSubtitle()}</p>
            )}
          </div>
        </div>
        
        <div className="flex items-center space-x-4">
          <div className="text-right">
            <p className="text-sm font-medium text-gray-900">{t.header.today}</p>
            <p className="text-xs text-gray-500">{currentDateTime}</p>
          </div>
          <div className="flex items-center space-x-2">
            <Button variant="ghost" size="sm" data-testid="button-notifications">
              <Bell className="w-4 h-4" />
            </Button>
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" size="sm" className="space-x-2" data-testid="button-language-switcher">
                  <Globe className="w-4 h-4 text-gray-500" />
                  <span className="text-sm">{t.header.language}</span>
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                <DropdownMenuItem 
                  onClick={() => setLanguage('th')}
                  className={language === 'th' ? 'bg-gray-100' : ''}
                  data-testid="menu-item-thai"
                >
                  🇹🇭 ไทย
                </DropdownMenuItem>
                <DropdownMenuItem 
                  onClick={() => setLanguage('en')}
                  className={language === 'en' ? 'bg-gray-100' : ''}
                  data-testid="menu-item-english"
                >
                  🇺🇸 English
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </div>
      </div>
    </header>
  );
}
