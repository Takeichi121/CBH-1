import { 
  users, 
  dailySalesReports, 
  storeSettings, 
  type User, 
  type InsertUser, 
  type DailySalesReport, 
  type InsertDailySales, 
  type StoreSettings, 
  type InsertStoreSettings 
} from "@shared/schema";
import { db } from "./db";
import { eq, desc, and } from "drizzle-orm";
import { randomUUID } from "crypto";

// Enhanced interface with new methods for BK Dashboard
export interface IStorage {
  // User methods
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;

  // Daily Sales Report methods
  createDailySalesReport(report: InsertDailySales): Promise<DailySalesReport>;
  getDailySalesReport(id: string): Promise<DailySalesReport | undefined>;
  getDailySalesReports(date?: string, limit?: number): Promise<DailySalesReport[]>;
  updateDailySalesReport(id: string, report: Partial<InsertDailySales>): Promise<DailySalesReport>;
  deleteDailySalesReport(id: string): Promise<boolean>;

  // Store Settings methods
  getStoreSettings(): Promise<StoreSettings | undefined>;
  updateStoreSettings(settings: InsertStoreSettings): Promise<StoreSettings>;

  // Dashboard Analytics methods
  getDashboardKPIs(date?: string): Promise<any>;
  getSalesByChannel(date?: string): Promise<any>;
}

export class DatabaseStorage implements IStorage {
  constructor() {
    // Initialize database with default data if needed
    this.initializeDefaults();
  }

  private async initializeDefaults() {
    try {
      // Check if store settings exist
      const existingSettings = await db.select().from(storeSettings).limit(1);
      if (existingSettings.length === 0) {
        await db.insert(storeSettings).values({
          storeName: "BK Grand Diamond Plaza",
          storeCode: "BK001GDP",
          dailyTarget: "250000"
        });
      }

      // Check if default user exists
      const existingUsers = await db.select().from(users).limit(1);
      if (existingUsers.length === 0) {
        await db.insert(users).values({
          username: "chanon",
          password: "password123", 
          name: "Chanon Jaimool",
          role: "manager"
        });
      }
    } catch (error) {
      console.error("Failed to initialize defaults:", error);
    }
  }

  // User methods
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db.insert(users).values(insertUser).returning();
    return user;
  }

  // Daily Sales Report methods
  async createDailySalesReport(insertReport: InsertDailySales): Promise<DailySalesReport> {
    const [report] = await db.insert(dailySalesReports).values(insertReport as any).returning();
    return report;
  }

  async getDailySalesReport(id: string): Promise<DailySalesReport | undefined> {
    const [report] = await db.select().from(dailySalesReports).where(eq(dailySalesReports.id, id));
    return report;
  }

  async getDailySalesReports(date?: string, limit: number = 10): Promise<DailySalesReport[]> {
    if (date) {
      const reports = await db.select().from(dailySalesReports)
        .where(eq(dailySalesReports.reportDate, date))
        .orderBy(desc(dailySalesReports.reportDate))
        .limit(limit);
      return reports;
    }
    
    const reports = await db.select().from(dailySalesReports)
      .orderBy(desc(dailySalesReports.reportDate))
      .limit(limit);
    return reports;
  }

  async updateDailySalesReport(id: string, updateData: Partial<InsertDailySales>): Promise<DailySalesReport> {
    const [updated] = await db
      .update(dailySalesReports)
      .set({ ...updateData, updatedAt: new Date() } as any)
      .where(eq(dailySalesReports.id, id))
      .returning();
    
    if (!updated) {
      throw new Error("Report not found");
    }
    
    return updated;
  }

  async deleteDailySalesReport(id: string): Promise<boolean> {
    const result = await db.delete(dailySalesReports).where(eq(dailySalesReports.id, id));
    return (result.rowCount ?? 0) > 0;
  }

  // Store Settings methods
  async getStoreSettings(): Promise<StoreSettings | undefined> {
    const [settings] = await db.select().from(storeSettings).limit(1);
    return settings;
  }

  async updateStoreSettings(updateData: InsertStoreSettings): Promise<StoreSettings> {
    const existing = await this.getStoreSettings();
    
    if (existing) {
      const [updated] = await db
        .update(storeSettings)
        .set({ ...updateData, updatedAt: new Date() })
        .where(eq(storeSettings.id, existing.id))
        .returning();
      return updated;
    } else {
      const [created] = await db.insert(storeSettings).values(updateData).returning();
      return created;
    }
  }

  // Dashboard Analytics methods
  async getDashboardKPIs(date?: string): Promise<any> {
    const targetDate = date || new Date().toISOString().split('T')[0];
    const reports = await this.getDailySalesReports(targetDate, 1);
    const todayReport = reports[0];

    // Calculate KPIs from actual report data
    if (todayReport) {
      const actualSales = parseFloat(todayReport.actualSales);
      const target = parseFloat(todayReport.dailyTarget);
      const transactions = todayReport.transactionCount;

      // Calculate percentage change (mock calculation for now)
      const changePercent = target > 0 ? ((actualSales - target) / target * 100).toFixed(1) : "0.0";
      const changeSign = parseFloat(changePercent) >= 0 ? "+" : "";

      return {
        dailySales: actualSales,
        dailySalesChange: `${changeSign}${changePercent}%`,
        transactionCount: transactions,
        transactionChange: "+8.2%", // Mock for now
        mtdSales: actualSales * 23, // Estimated MTD
        mtdTarget: target > 0 ? ((actualSales * 30 / target) * 100).toFixed(1) + "%" : "0%",
        gsiScore: parseFloat(todayReport.gsi || "0"),
        gsiRating: todayReport.gsi ? (parseFloat(todayReport.gsi) >= 4.5 ? "ดีเยี่ยม" : "ดี") : "ไม่มีข้อมูล"
      };
    }

    // Return empty data if no reports
    return {
      dailySales: 0,
      dailySalesChange: "0.0%",
      transactionCount: 0,
      transactionChange: "0.0%",
      mtdSales: 0,
      mtdTarget: "0.0%",
      gsiScore: 0,
      gsiRating: "ไม่มีข้อมูล"
    };
  }

  async getSalesByChannel(date?: string): Promise<any> {
    const targetDate = date || new Date().toISOString().split('T')[0];
    const reports = await this.getDailySalesReports(targetDate, 1);
    const todayReport = reports[0];

    if (todayReport) {
      const dineIn = parseFloat(todayReport.dineIn);
      const takeAway = parseFloat(todayReport.takeAway);
      const delivery = parseFloat(todayReport.delivery);
      const total = dineIn + takeAway + delivery;

      return {
        dineIn: {
          amount: dineIn,
          percentage: total > 0 ? (dineIn / total * 100).toFixed(1) : 0
        },
        takeAway: {
          amount: takeAway,
          percentage: total > 0 ? (takeAway / total * 100).toFixed(1) : 0
        },
        delivery: {
          amount: delivery,
          percentage: total > 0 ? (delivery / total * 100).toFixed(1) : 0
        }
      };
    }

    // Return empty data if no reports
    return {
      dineIn: { amount: 0, percentage: 0 },
      takeAway: { amount: 0, percentage: 0 },
      delivery: { amount: 0, percentage: 0 }
    };
  }
}

export const storage = new DatabaseStorage();
